
<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

include_once("connection.php");

// Debug: Log POST data
error_log("========================================");
error_log("ADD_ATTENDANCE.PHP ACCESSED");
error_log("POST Data: " . print_r($_POST, true));
error_log("========================================");

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data with validation
    $employee_id = isset($_POST['employee_id']) ? trim($_POST['employee_id']) : '';
    $date = isset($_POST['date']) ? trim($_POST['date']) : '';
    $status = isset($_POST['status']) ? trim($_POST['status']) : ''; // AM Status
    $pm_status = isset($_POST['pm_status']) ? trim($_POST['pm_status']) : 'Absent'; // PM Status
    $night_status = isset($_POST['night_status']) ? trim($_POST['night_status']) : 'Absent'; // Night Status
    $remarks = isset($_POST['remarks']) ? trim($_POST['remarks']) : '';
    $attendance_id = isset($_POST['attendance_id']) ? intval($_POST['attendance_id']) : 0;
    
    // Get leave type - only relevant if status is 'On Leave'
    $leave_type = isset($_POST['leave_type']) ? trim($_POST['leave_type']) : NULL;
    if ($status !== 'On Leave') {
        $leave_type = NULL;
    }
    
    // Get holiday type - only relevant if status is 'Holiday'
    $holiday_type = isset($_POST['holiday_type']) ? trim($_POST['holiday_type']) : NULL;
    if ($status !== 'Holiday') {
        $holiday_type = NULL;
    }
    
    // Time fields – set to NULL if empty or '00:00:00'
    $time_in_am = (!empty($_POST['time_in_am']) && $_POST['time_in_am'] !== '00:00:00') ? trim($_POST['time_in_am']) : NULL;
    $time_out_am = (!empty($_POST['time_out_am']) && $_POST['time_out_am'] !== '00:00:00') ? trim($_POST['time_out_am']) : NULL;
    $time_in_pm = (!empty($_POST['time_in_pm']) && $_POST['time_in_pm'] !== '00:00:00') ? trim($_POST['time_in_pm']) : NULL;
    $time_out_pm = (!empty($_POST['time_out_pm']) && $_POST['time_out_pm'] !== '00:00:00') ? trim($_POST['time_out_pm']) : NULL;
    $time_in_night = (!empty($_POST['time_in_night']) && $_POST['time_in_night'] !== '00:00:00') ? trim($_POST['time_in_night']) : NULL;
    $time_out_night = (!empty($_POST['time_out_night']) && $_POST['time_out_night'] !== '00:00:00') ? trim($_POST['time_out_night']) : NULL;
    
    // Function to calculate hours between two times
    function calculateHours($time_in, $time_out) {
        if (empty($time_in) || empty($time_out) || $time_in === '00:00:00' || $time_out === '00:00:00') {
            return 0;
        }
        
        $time_in_ts = strtotime($time_in);
        $time_out_ts = strtotime($time_out);
        
        if ($time_out_ts < $time_in_ts) {
            $time_out_ts += 86400; // Add 24 hours if time_out is next day
        }
        
        $hours = round(($time_out_ts - $time_in_ts) / 3600, 2);
        return $hours;
    }
    
    // Calculate total hours (including night session)
    $am_hours = calculateHours($time_in_am, $time_out_am);
    $pm_hours = calculateHours($time_in_pm, $time_out_pm);
    $night_hours = calculateHours($time_in_night, $time_out_night);
    $total_hours = $am_hours + $pm_hours + $night_hours;
    
  // If status is On Leave, force all time fields to NULL and set all statuses to On Leave
if ($status === 'On Leave') {
    $time_in_am = $time_out_am = $time_in_pm = $time_out_pm = $time_in_night = $time_out_night = NULL;
    $pm_status = 'On Leave';  // Force PM status to On Leave
    $night_status = 'On Leave'; // Force Night status to On Leave
    $total_hours = 0;
    error_log("ON LEAVE DETECTED - Setting pm_status=On Leave, night_status=On Leave");
}

// If status is Holiday, set all statuses to Holiday
if ($status === 'Holiday') {
    // Force PM and Night status to Holiday
    $pm_status = 'Holiday';
    $night_status = 'Holiday';
    
    // Keep time fields as is - don't set to NULL (pwede mag-time in)
    error_log("HOLIDAY DETECTED - Setting pm_status=Holiday, night_status=Holiday, keeping time fields");
}
    // If AM is Absent, set AM time fields to NULL
    if ($status === 'Absent') {
        $time_in_am = $time_out_am = NULL;
    }
    
    // If PM is Absent, set PM time fields to NULL
    if ($pm_status === 'Absent') {
        $time_in_pm = $time_out_pm = NULL;
    }
    
    // If Night is Absent, set Night time fields to NULL
    if ($night_status === 'Absent') {
        $time_in_night = $time_out_night = NULL;
    }
    
    // If status is Present but no times, set to Absent
    if ($status === 'Present' && !$time_in_am && !$time_out_am) {
        $status = 'Absent';
    }
    
    // If PM status is Present but no times, set to Absent
    if ($pm_status === 'Present' && !$time_in_pm && !$time_out_pm) {
        $pm_status = 'Absent';
    }
    
    // If Night status is Present but no times, set to Absent
    if ($night_status === 'Present' && !$time_in_night && !$time_out_night) {
        $night_status = 'Absent';
    }
    
    error_log("Processing attendance for:");
    error_log("- Employee ID: " . $employee_id);
    error_log("- Date: " . $date);
    error_log("- AM Status: " . $status);
    error_log("- PM Status: " . $pm_status);
    error_log("- Night Status: " . $night_status);
    error_log("- Leave Type: " . ($leave_type ? $leave_type : 'NULL'));
    error_log("- Holiday Type: " . ($holiday_type ? $holiday_type : 'NULL'));
    error_log("- Time In AM: " . ($time_in_am ? $time_in_am : 'NULL'));
    error_log("- Time Out AM: " . ($time_out_am ? $time_out_am : 'NULL'));
    error_log("- Time In PM: " . ($time_in_pm ? $time_in_pm : 'NULL'));
    error_log("- Time Out PM: " . ($time_out_pm ? $time_out_pm : 'NULL'));
    error_log("- Time In Night: " . ($time_in_night ? $time_in_night : 'NULL'));
    error_log("- Time Out Night: " . ($time_out_night ? $time_out_night : 'NULL'));
    error_log("- AM Hours: " . $am_hours);
    error_log("- PM Hours: " . $pm_hours);
    error_log("- Night Hours: " . $night_hours);
    error_log("- Total Hours: " . $total_hours);
    error_log("- Remarks: " . $remarks);
    error_log("- Attendance ID: " . $attendance_id);
    
    // Validate required fields
    if (empty($employee_id) || empty($date) || empty($status)) {
        $_SESSION['error'] = "Please fill all required fields";
        error_log("VALIDATION FAILED: Missing required fields");
        header("Location: attendance.php?date=" . urlencode($date));
        exit;
    }
    
    // If status is On Leave, validate leave type
    if ($status === 'On Leave' && empty($leave_type)) {
        $_SESSION['error'] = "Please select a leave type";
        error_log("VALIDATION FAILED: Missing leave type");
        header("Location: attendance.php?date=" . urlencode($date));
        exit;
    }
    
    // If status is Holiday, validate holiday type
    if ($status === 'Holiday' && empty($holiday_type)) {
        $_SESSION['error'] = "Please select holiday type";
        error_log("VALIDATION FAILED: Missing holiday type");
        header("Location: attendance.php?date=" . urlencode($date));
        exit;
    }
    
    try {
        // Check if attendance already exists for this employee on this date
        $check_sql = "SELECT id FROM attendance WHERE employee_id = ? AND DATE(date) = DATE(?)";
        error_log("Checking existing record: " . $check_sql);
        
        $check_stmt = $conn->prepare($check_sql);
        if (!$check_stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $check_stmt->bind_param("is", $employee_id, $date);
        if (!$check_stmt->execute()) {
            throw new Exception("Execute failed: " . $check_stmt->error);
        }
        
        $check_result = $check_stmt->get_result();
        $existing_record = $check_result->fetch_assoc();
        
        if ($existing_record) {
            // Update existing record - INCLUDING HOLIDAY TYPE
            $attendance_id = $existing_record['id'];
            error_log("Updating existing record ID: " . $attendance_id);
            
            // Check if time_in_night and holiday_type columns exist
            $columns_check = $conn->query("SHOW COLUMNS FROM attendance LIKE 'time_in_night'");
            $has_night_columns = $columns_check->num_rows > 0;
            
            $holiday_check = $conn->query("SHOW COLUMNS FROM attendance LIKE 'holiday_type'");
            $has_holiday_column = $holiday_check->num_rows > 0;
            
            if ($has_night_columns && $has_holiday_column) {
                // Update with night session columns and holiday type
                $update_sql = "UPDATE attendance SET 
                              status = ?,
                              pm_status = ?,
                              night_status = ?,
                              time_in_am = ?, 
                              time_out_am = ?, 
                              time_in_pm = ?,
                              time_out_pm = ?,
                              time_in_night = ?,
                              time_out_night = ?,
                              remarks = ?,
                              leave_type = ?,
                              holiday_type = ?,
                              total_hours = ?,
                              updated_at = CURRENT_TIMESTAMP
                              WHERE id = ?";
                
                error_log("Update SQL: " . $update_sql);
                
                $update_stmt = $conn->prepare($update_sql);
                if (!$update_stmt) {
                    throw new Exception("Update prepare failed: " . $conn->error);
                }
                
                $update_stmt->bind_param("ssssssssssssdi", 
                    $status,
                    $pm_status,
                    $night_status,
                    $time_in_am, 
                    $time_out_am, 
                    $time_in_pm, 
                    $time_out_pm,
                    $time_in_night,
                    $time_out_night,
                    $remarks, 
                    $leave_type, 
                    $holiday_type, 
                    $total_hours,
                    $attendance_id
                );
            } else {
                $_SESSION['error'] = "Database needs to be updated. Please run the SQL commands.";
                header("Location: attendance.php?date=" . urlencode($date));
                exit;
            }
            
            if ($update_stmt->execute()) {
                $_SESSION['success'] = "✅ Attendance record updated successfully for Employee ID: $employee_id";
                error_log("UPDATE SUCCESSFUL - Affected rows: " . $update_stmt->affected_rows);
            } else {
                throw new Exception("Update execute failed: " . $update_stmt->error);
            }
            
            $update_stmt->close();
        } else {
            // Insert new record - INCLUDING HOLIDAY TYPE
            error_log("Inserting new record");
            
            // Check if columns exist
            $columns_check = $conn->query("SHOW COLUMNS FROM attendance LIKE 'time_in_night'");
            $has_night_columns = $columns_check->num_rows > 0;
            
            $holiday_check = $conn->query("SHOW COLUMNS FROM attendance LIKE 'holiday_type'");
            $has_holiday_column = $holiday_check->num_rows > 0;
            
            if ($has_night_columns && $has_holiday_column) {
                // Insert with night session columns and holiday type
                $insert_sql = "INSERT INTO attendance (
                              employee_id, 
                              date, 
                              status,
                              pm_status,
                              night_status,
                              time_in_am, 
                              time_out_am, 
                              time_in_pm, 
                              time_out_pm,
                              time_in_night,
                              time_out_night,
                              remarks, 
                              leave_type,
                              holiday_type,
                              total_hours,
                              created_at
                              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
                
                error_log("Insert SQL: " . $insert_sql);
                
                $insert_stmt = $conn->prepare($insert_sql);
                if (!$insert_stmt) {
                    throw new Exception("Insert prepare failed: " . $conn->error);
                }
                
                $insert_stmt->bind_param("isssssssssssssd", 
                    $employee_id, 
                    $date, 
                    $status,
                    $pm_status,
                    $night_status,
                    $time_in_am, 
                    $time_out_am, 
                    $time_in_pm, 
                    $time_out_pm,
                    $time_in_night,
                    $time_out_night,
                    $remarks, 
                    $leave_type,
                    $holiday_type,
                    $total_hours
                );
            } else {
                $_SESSION['error'] = "Database needs to be updated. Please run the SQL commands.";
                header("Location: attendance.php?date=" . urlencode($date));
                exit;
            }
            
            if ($insert_stmt->execute()) {
                $new_id = $insert_stmt->insert_id;
                $_SESSION['success'] = "✅ Attendance record added successfully for Employee ID: $employee_id";
                error_log("INSERT SUCCESSFUL - New ID: " . $new_id);
            } else {
                throw new Exception("Insert execute failed: " . $insert_stmt->error);
            }
            
            $insert_stmt->close();
        }
        
        $check_stmt->close();
        
    } catch (Exception $e) {
        error_log("DATABASE ERROR: " . $e->getMessage());
        $_SESSION['error'] = "Database error: " . $e->getMessage();
    }
    
    // Check for database errors
    if ($conn->error) {
        error_log("MySQL Error: " . $conn->error);
        $_SESSION['error'] = "MySQL Error: " . $conn->error;
    }
    
    // Get employee name for enhanced success message
    if (isset($_SESSION['success'])) {
        $name_sql = "SELECT CONCAT(first_name, ' ', last_name) as full_name FROM employees WHERE id = ?";
        $name_stmt = $conn->prepare($name_sql);
        if ($name_stmt) {
            $name_stmt->bind_param("i", $employee_id);
            $name_stmt->execute();
            $name_result = $name_stmt->get_result();
            if ($name_row = $name_result->fetch_assoc()) {
                $status_text = $status;
                if ($status === 'Holiday' && !empty($holiday_type)) {
                    $status_text .= " ($holiday_type)";
                } elseif ($status === 'On Leave' && !empty($leave_type)) {
                    $status_text .= " ($leave_type)";
                }
                $_SESSION['success'] = "✅ Attendance record for " . $name_row['full_name'] . " on " . date('F j, Y', strtotime($date)) . " (Status: $status_text) has been saved successfully.";
            }
            $name_stmt->close();
        }
    }
    
    // Redirect back to attendance page
    $redirect_url = "attendance.php?date=" . urlencode($date);
    error_log("Redirecting to: " . $redirect_url);
    
    header("Location: " . $redirect_url);
    exit;
    
} else {
    error_log("INVALID REQUEST METHOD: " . $_SERVER["REQUEST_METHOD"]);
    $_SESSION['error'] = "Invalid request method";
    header("Location: attendance.php");
    exit;
}

$conn->close();
?> get_attendance.php <?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

include_once("connection.php");

$employee_id = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : 0;
$date = isset($_GET['date']) ? $_GET['date'] : '';

if (!$employee_id || !$date) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

try {
    // UPDATED: Include pm_status and night_status fields
$sql = "SELECT id, employee_id, date, status, pm_status, night_status,
               time_in_am, time_out_am, 
               time_in_pm, time_out_pm,
               time_in_night, time_out_night,
               remarks, leave_type, holiday_type,
               total_hours
        FROM attendance 
        WHERE employee_id = ? AND DATE(date) = DATE(?)";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("is", $employee_id, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        // Format times for display
        $row['success'] = true;
        
        // Convert NULL to empty string for JSON
        foreach ($row as $key => $value) {
            if ($value === null) {
                $row[$key] = '';
            }
        }
        
        // Format times for 12-hour display
        if (!empty($row['time_in_am']) && $row['time_in_am'] != '00:00:00') {
            $time = strtotime($row['time_in_am']);
            $row['time_in_am_formatted'] = date('h:i A', $time);
        } else {
            $row['time_in_am_formatted'] = '';
        }
        
        if (!empty($row['time_out_am']) && $row['time_out_am'] != '00:00:00') {
            $time = strtotime($row['time_out_am']);
            $row['time_out_am_formatted'] = date('h:i A', $time);
        } else {
            $row['time_out_am_formatted'] = '';
        }
        
        if (!empty($row['time_in_pm']) && $row['time_in_pm'] != '00:00:00') {
            $time = strtotime($row['time_in_pm']);
            $row['time_in_pm_formatted'] = date('h:i A', $time);
        } else {
            $row['time_in_pm_formatted'] = '';
        }
        
        if (!empty($row['time_out_pm']) && $row['time_out_pm'] != '00:00:00') {
            $time = strtotime($row['time_out_pm']);
            $row['time_out_pm_formatted'] = date('h:i A', $time);
        } else {
            $row['time_out_pm_formatted'] = '';
        }
        
        // Format night times
        if (!empty($row['time_in_night']) && $row['time_in_night'] != '00:00:00') {
            $time = strtotime($row['time_in_night']);
            $row['time_in_night_formatted'] = date('h:i A', $time);
        } else {
            $row['time_in_night_formatted'] = '';
        }
        
        if (!empty($row['time_out_night']) && $row['time_out_night'] != '00:00:00') {
            $time = strtotime($row['time_out_night']);
            $row['time_out_night_formatted'] = date('h:i A', $time);
        } else {
            $row['time_out_night_formatted'] = '';
        }
        
        // Add debug info
        error_log("get_attendance.php - Found record for employee $employee_id on $date");
        error_log("Status: " . $row['status']);
        error_log("PM Status: " . $row['pm_status']);
        error_log("Night Status: " . $row['night_status']);
        if ($row['status'] == 'Holiday') {
            error_log("Holiday Type: " . $row['holiday_type']);
        } elseif ($row['status'] == 'On Leave') {
            error_log("Leave Type: " . $row['leave_type']);
        }
        
        echo json_encode($row);
    } else {
        // No existing record - return default values for new entry
        error_log("get_attendance.php - No record found for employee $employee_id on $date");
        
        echo json_encode([
            'success' => true,
            'id' => '',
            'employee_id' => $employee_id,
            'date' => $date,
            'status' => 'Present',
            'pm_status' => 'Present',
            'night_status' => 'Present',
            'time_in_am' => '',
            'time_out_am' => '',
            'time_in_pm' => '',
            'time_out_pm' => '',
            'time_in_night' => '',
            'time_out_night' => '',
            'remarks' => '',
            'leave_type' => '',
            'holiday_type' => '',
            'total_hours' => '0.00',
            'time_in_am_formatted' => '',
            'time_out_am_formatted' => '',
            'time_in_pm_formatted' => '',
            'time_out_pm_formatted' => '',
            'time_in_night_formatted' => '',
            'time_out_night_formatted' => ''
        ]);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    error_log("Error in get_attendance.php: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}

$conn->close();
?> get_site_employess_attendance.php <?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['Admin_User'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

include_once("connection.php");

// Get parameters
$site_id = isset($_GET['site_id']) ? intval($_GET['site_id']) : 0;
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Validate date format
if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $date)) {
    $date = date('Y-m-d');
}

if ($site_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid site ID']);
    exit;
}

// Get site details
$site_query = "SELECT s.*, so.assignment_type, so.person_group 
               FROM site_monitoring s 
               LEFT JOIN site_others so ON s.id = so.site_id 
               WHERE s.id = ?";
$site_stmt = $conn->prepare($site_query);
if (!$site_stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
    exit;
}
$site_stmt->bind_param("i", $site_id);
$site_stmt->execute();
$site_result = $site_stmt->get_result();
$site = $site_result->fetch_assoc();

if (!$site) {
    echo json_encode(['success' => false, 'message' => 'Site not found']);
    exit;
}

// Get total employees count for this site
$total_employees_query = "SELECT COUNT(*) as total 
                          FROM site_employee 
                          WHERE site_id = ? AND status = 'active'";
$total_stmt = $conn->prepare($total_employees_query);
$total_stmt->bind_param("i", $site_id);
$total_stmt->execute();
$total_result = $total_stmt->get_result();
$total_row = $total_result->fetch_assoc();
$total_employees_count = $total_row['total'] ?? 0;

// UPDATED: With night session fields (night_status, time_in_night, time_out_night)
$query = "SELECT 
            e.id,
            e.first_name,
            e.middle_name,
            e.last_name,
            e.position,
            e.email,
            se.assigned_date,
            a.id as attendance_id,
            a.status,              /* AM status */
            a.pm_status,            /* PM status */
            a.night_status,         /* Night status */
            a.time_in_am,
            a.time_out_am,
            a.time_in_pm,
            a.time_out_pm,
            a.time_in_night,        /* Night time in */
            a.time_out_night,       /* Night time out */
            a.remarks,
            a.total_hours,
            a.leave_type,
            a.holiday_type
          FROM employees e
          INNER JOIN site_employee se ON e.id = se.employee_id
          LEFT JOIN attendance a ON e.id = a.employee_id AND DATE(a.date) = DATE(?)
          WHERE se.site_id = ? AND se.status = 'active'
          AND e.status = 'active'
          ORDER BY e.first_name, e.last_name";

$stmt = $conn->prepare($query);
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
    exit;
}

$stmt->bind_param("si", $date, $site_id);
$stmt->execute();
$result = $stmt->get_result();

$employees = [];
$present_count = 0;
$absent_count = 0;
$leave_count = 0;

while ($row = $result->fetch_assoc()) {
    // Set default values if NULL
    $row['status_am'] = $row['status'] ?? 'Absent';      // Use status for AM
    $row['status_pm'] = $row['pm_status'] ?? 'Absent';   // Use pm_status for PM
    $row['status_night'] = $row['night_status'] ?? 'Absent'; // Use night_status for Night
    $row['time_in_am'] = $row['time_in_am'] ?? null;
    $row['time_out_am'] = $row['time_out_am'] ?? null;
    $row['time_in_pm'] = $row['time_in_pm'] ?? null;
    $row['time_out_pm'] = $row['time_out_pm'] ?? null;
    $row['time_in_night'] = $row['time_in_night'] ?? null;
    $row['time_out_night'] = $row['time_out_night'] ?? null;
    $row['total_hours'] = $row['total_hours'] ?? 0.00;
    $row['remarks'] = $row['remarks'] ?? '';
    $row['leave_type'] = $row['leave_type'] ?? '';
    $row['holiday_type'] = $row['holiday_type'] ?? '';
    
    // Format full name with middle name
    $full_name = $row['first_name'];
    if (!empty($row['middle_name'])) {
        $full_name .= ' ' . substr($row['middle_name'], 0, 1) . '.';
    }
    $full_name .= ' ' . $row['last_name'];
    $row['full_name'] = $full_name;
    
    // Determine overall status for the day
    if ($row['status_am'] == 'Present' || $row['status_pm'] == 'Present' || $row['status_night'] == 'Present') {
        $row['overall_status'] = 'Present';
        $present_count++;
    } elseif ($row['status_am'] == 'On Leave' || $row['status_pm'] == 'On Leave' || $row['status_night'] == 'On Leave') {
        $row['overall_status'] = 'On Leave';
        $leave_count++;
    } elseif ($row['status_am'] == 'Holiday' || $row['status_pm'] == 'Holiday' || $row['status_night'] == 'Holiday') {
        $row['overall_status'] = 'Holiday';
        $present_count++; // Count as present for holiday (since they can still log time)
    } else {
        $row['overall_status'] = 'Absent';
        $absent_count++;
    }
    
    // Check if employee has any time logged
    $has_time = (
        (!empty($row['time_in_am']) && $row['time_in_am'] != '00:00:00' && $row['time_in_am'] != '--:--') ||
        (!empty($row['time_out_am']) && $row['time_out_am'] != '00:00:00' && $row['time_out_am'] != '--:--') ||
        (!empty($row['time_in_pm']) && $row['time_in_pm'] != '00:00:00' && $row['time_in_pm'] != '--:--') ||
        (!empty($row['time_out_pm']) && $row['time_out_pm'] != '00:00:00' && $row['time_out_pm'] != '--:--') ||
        (!empty($row['time_in_night']) && $row['time_in_night'] != '00:00:00' && $row['time_in_night'] != '--:--') ||
        (!empty($row['time_out_night']) && $row['time_out_night'] != '00:00:00' && $row['time_out_night'] != '--:--')
    );
    $row['has_time'] = $has_time;
    
    // Format times for display (remove seconds) - KEEP ORIGINAL FOR REFERENCE
    $row['time_in_am_raw'] = $row['time_in_am'];
    $row['time_out_am_raw'] = $row['time_out_am'];
    $row['time_in_pm_raw'] = $row['time_in_pm'];
    $row['time_out_pm_raw'] = $row['time_out_pm'];
    $row['time_in_night_raw'] = $row['time_in_night'];
    $row['time_out_night_raw'] = $row['time_out_night'];
    
    // Format for display
    if ($row['time_in_am'] && $row['time_in_am'] != '00:00:00') {
        $row['time_in_am_display'] = substr($row['time_in_am'], 0, 5);
    } else {
        $row['time_in_am_display'] = '--:--';
    }
    
    if ($row['time_out_am'] && $row['time_out_am'] != '00:00:00') {
        $row['time_out_am_display'] = substr($row['time_out_am'], 0, 5);
    } else {
        $row['time_out_am_display'] = '--:--';
    }
    
    if ($row['time_in_pm'] && $row['time_in_pm'] != '00:00:00') {
        $row['time_in_pm_display'] = substr($row['time_in_pm'], 0, 5);
    } else {
        $row['time_in_pm_display'] = '--:--';
    }
    
    if ($row['time_out_pm'] && $row['time_out_pm'] != '00:00:00') {
        $row['time_out_pm_display'] = substr($row['time_out_pm'], 0, 5);
    } else {
        $row['time_out_pm_display'] = '--:--';
    }
    
    if ($row['time_in_night'] && $row['time_in_night'] != '00:00:00') {
        $row['time_in_night_display'] = substr($row['time_in_night'], 0, 5);
    } else {
        $row['time_in_night_display'] = '--:--';
    }
    
    if ($row['time_out_night'] && $row['time_out_night'] != '00:00:00') {
        $row['time_out_night_display'] = substr($row['time_out_night'], 0, 5);
    } else {
        $row['time_out_night_display'] = '--:--';
    }
    
    // Create combined time string for display
    $time_details = [];
    if ($row['time_in_am_display'] != '--:--' || $row['time_out_am_display'] != '--:--') {
        $time_details[] = "AM: {$row['time_in_am_display']}-{$row['time_out_am_display']}";
    }
    if ($row['time_in_pm_display'] != '--:--' || $row['time_out_pm_display'] != '--:--') {
        $time_details[] = "PM: {$row['time_in_pm_display']}-{$row['time_out_pm_display']}";
    }
    if ($row['time_in_night_display'] != '--:--' || $row['time_out_night_display'] != '--:--') {
        $time_details[] = "Night: {$row['time_in_night_display']}-{$row['time_out_night_display']}";
    }
    $row['time_display'] = implode(' | ', $time_details);
    
    $employees[] = $row;
}

// Recalculate absent count based on total employees
$absent_count = max(0, $total_employees_count - $present_count - $leave_count);

$response = [
    'success' => true,
    'site_id' => $site_id,
    'site_name' => $site['site_name'] ?? 'Unknown',
    'site_manager' => $site['site_manager'] ?? 'N/A',
    'site_address' => $site['site_address'] ?? 'N/A',
    'date' => $date,
    'employees' => $employees,
    'summary' => [
        'total' => $total_employees_count,
        'present' => $present_count,
        'absent' => $absent_count,
        'leave' => $leave_count
    ],
    'debug' => [
        'employees_found' => count($employees),
        'date_used' => $date
    ]
];

echo json_encode($response);

$site_stmt->close();
$total_stmt->close();
$stmt->close();
$conn->close();
?>