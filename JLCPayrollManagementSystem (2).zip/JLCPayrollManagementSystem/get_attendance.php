<?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

include_once("connection.php");

$employee_id = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : 0;
$date = isset($_GET['date']) ? $_GET['date'] : '';

if (!$employee_id || !$date) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

try {
    // UPDATED: Include pm_status and night_status fields
$sql = "SELECT id, employee_id, date, status, pm_status, night_status,
               time_in_am, time_out_am, 
               time_in_pm, time_out_pm,
               time_in_night, time_out_night,
               remarks, leave_type, holiday_type,
               total_hours
        FROM attendance 
        WHERE employee_id = ? AND DATE(date) = DATE(?)";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("is", $employee_id, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        // Format times for display
        $row['success'] = true;
        
        // Convert NULL to empty string for JSON
        foreach ($row as $key => $value) {
            if ($value === null) {
                $row[$key] = '';
            }
        }
        
        // Format times for 12-hour display
        if (!empty($row['time_in_am']) && $row['time_in_am'] != '00:00:00') {
            $time = strtotime($row['time_in_am']);
            $row['time_in_am_formatted'] = date('h:i A', $time);
        } else {
            $row['time_in_am_formatted'] = '';
        }
        
        if (!empty($row['time_out_am']) && $row['time_out_am'] != '00:00:00') {
            $time = strtotime($row['time_out_am']);
            $row['time_out_am_formatted'] = date('h:i A', $time);
        } else {
            $row['time_out_am_formatted'] = '';
        }
        
        if (!empty($row['time_in_pm']) && $row['time_in_pm'] != '00:00:00') {
            $time = strtotime($row['time_in_pm']);
            $row['time_in_pm_formatted'] = date('h:i A', $time);
        } else {
            $row['time_in_pm_formatted'] = '';
        }
        
        if (!empty($row['time_out_pm']) && $row['time_out_pm'] != '00:00:00') {
            $time = strtotime($row['time_out_pm']);
            $row['time_out_pm_formatted'] = date('h:i A', $time);
        } else {
            $row['time_out_pm_formatted'] = '';
        }
        
        // Format night times
        if (!empty($row['time_in_night']) && $row['time_in_night'] != '00:00:00') {
            $time = strtotime($row['time_in_night']);
            $row['time_in_night_formatted'] = date('h:i A', $time);
        } else {
            $row['time_in_night_formatted'] = '';
        }
        
        if (!empty($row['time_out_night']) && $row['time_out_night'] != '00:00:00') {
            $time = strtotime($row['time_out_night']);
            $row['time_out_night_formatted'] = date('h:i A', $time);
        } else {
            $row['time_out_night_formatted'] = '';
        }
        
        // Add debug info
        error_log("get_attendance.php - Found record for employee $employee_id on $date");
        error_log("Status: " . $row['status']);
        error_log("PM Status: " . $row['pm_status']);
        error_log("Night Status: " . $row['night_status']);
        if ($row['status'] == 'Holiday') {
            error_log("Holiday Type: " . $row['holiday_type']);
        } elseif ($row['status'] == 'On Leave') {
            error_log("Leave Type: " . $row['leave_type']);
        }
        
        echo json_encode($row);
    } else {
        // No existing record - return default values for new entry
        error_log("get_attendance.php - No record found for employee $employee_id on $date");
        
        echo json_encode([
            'success' => true,
            'id' => '',
            'employee_id' => $employee_id,
            'date' => $date,
            'status' => 'Present',
            'pm_status' => 'Present',
            'night_status' => 'Present',
            'time_in_am' => '',
            'time_out_am' => '',
            'time_in_pm' => '',
            'time_out_pm' => '',
            'time_in_night' => '',
            'time_out_night' => '',
            'remarks' => '',
            'leave_type' => '',
            'holiday_type' => '',
            'total_hours' => '0.00',
            'time_in_am_formatted' => '',
            'time_out_am_formatted' => '',
            'time_in_pm_formatted' => '',
            'time_out_pm_formatted' => '',
            'time_in_night_formatted' => '',
            'time_out_night_formatted' => ''
        ]);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    error_log("Error in get_attendance.php: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}

$conn->close();
?>