<?php
session_start();

// Redirect if the admin is not logged in
if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

// Include database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "payrollsystem";

$conn = new mysqli($servername, $username, $password, $database);

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define working days per month for calculation
define('WORKING_DAYS_PER_MONTH', 22);
define('HOURS_PER_DAY', 8);

// Handle AJAX request for salary report
if (isset($_POST['ajax']) && $_POST['ajax'] == 'generate_report') {
    header('Content-Type: application/json');
    
    $date_from = $_POST['date_from'];
    $date_to = $_POST['date_to'];
    
    // Fetch all active employees with their salary and deduction data
    $reportQuery = "
        SELECT 
            e.id, 
            CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
            e.position,
            e.daily_salary,
            e.hourly_rate,
            CASE 
                WHEN e.daily_salary > 0 THEN e.daily_salary * " . WORKING_DAYS_PER_MONTH . "
                WHEN e.hourly_rate > 0 THEN e.hourly_rate * " . HOURS_PER_DAY . " * " . WORKING_DAYS_PER_MONTH . "
                ELSE 0
            END AS monthly_salary,
            COALESCE(SUM(d.amount), 0) AS total_deductions,
            CASE 
                WHEN e.daily_salary > 0 THEN (e.daily_salary * " . WORKING_DAYS_PER_MONTH . " - COALESCE(SUM(d.amount), 0))
                WHEN e.hourly_rate > 0 THEN (e.hourly_rate * " . HOURS_PER_DAY . " * " . WORKING_DAYS_PER_MONTH . " - COALESCE(SUM(d.amount), 0))
                ELSE 0
            END AS net_salary,
            sm.site_name
        FROM employees e
        LEFT JOIN deduction d ON e.id = d.employee_id AND d.status != 'disabled'
        LEFT JOIN site_employee se ON e.id = se.employee_id
        LEFT JOIN site_monitoring sm ON se.site_id = sm.id
        WHERE e.status = 'active'
        GROUP BY e.id, sm.id
        ORDER BY e.first_name, e.last_name
    ";
    
    $reportResult = $conn->query($reportQuery);
    
    $employees = [];
    $total_gross = 0;
    $total_deductions = 0;
    $total_net = 0;
    
    if ($reportResult && $reportResult->num_rows > 0) {
        while ($row = $reportResult->fetch_assoc()) {
            $employees[] = $row;
            $total_gross += $row['monthly_salary'];
            $total_deductions += $row['total_deductions'];
            $total_net += $row['net_salary'];
        }
    }
    
    echo json_encode([
        'success' => true,
        'employees' => $employees,
        'totals' => [
            'count' => count($employees),
            'gross' => $total_gross,
            'deductions' => $total_deductions,
            'net' => $total_net
        ],
        'date_from' => date('F d, Y', strtotime($date_from)),
        'date_to' => date('F d, Y', strtotime($date_to))
    ]);
    exit;
}

// First, let's check the structure of the payroll table to see what columns exist
$payrollColumns = [];
$checkPayrollTable = $conn->query("SHOW COLUMNS FROM payroll");
if ($checkPayrollTable) {
    while ($column = $checkPayrollTable->fetch_assoc()) {
        $payrollColumns[] = $column['Field'];
    }
}

// Fetch employee salary slip details (if employee_id is passed via GET)
$employeeData = null;
$deductionsData = [];
$payrollId = null;

if (isset($_GET['employee_id'])) {
    $employeeId = $_GET['employee_id'];

    // Check if payroll record already exists for the employee
    $payrollQuery = "
        SELECT id FROM payroll 
        WHERE employee_id = ? 
        LIMIT 1
    ";
    $stmt = $conn->prepare($payrollQuery);
    $stmt->bind_param("i", $employeeId);
    $stmt->execute();
    $payrollResult = $stmt->get_result();

    // If payroll record does not exist, create a new one
    if ($payrollResult->num_rows === 0) {
        // Build the INSERT query dynamically based on existing columns
        $insertFields = [];
        $insertValues = [];
        $paramTypes = "";
        $paramValues = [];
        
        // Always include these basic fields
        $insertFields[] = "employee_id";
        $insertValues[] = "?";
        $paramTypes .= "i";
        $paramValues[] = $employeeId;
        
        // Check and add date fields
        if (in_array('date_from', $payrollColumns)) {
            $insertFields[] = "date_from";
            $insertValues[] = "NOW()";
        }
        
        if (in_array('date_to', $payrollColumns)) {
            $insertFields[] = "date_to";
            $insertValues[] = "NOW() + INTERVAL 1 MONTH";
        }
        
        // Check for any date column that might be required
        if (in_array('date', $payrollColumns)) {
            $insertFields[] = "`date`";
            $insertValues[] = "NOW()";
        }
        
        if (in_array('created_at', $payrollColumns)) {
            $insertFields[] = "created_at";
            $insertValues[] = "NOW()";
        }
        
        if (in_array('updated_at', $payrollColumns)) {
            $insertFields[] = "updated_at";
            $insertValues[] = "NOW()";
        }
        
        // Check for status column
        if (in_array('status', $payrollColumns)) {
            $insertFields[] = "status";
            $insertValues[] = "'active'";
        }
        
        // Check for is_active column
        if (in_array('is_active', $payrollColumns)) {
            $insertFields[] = "is_active";
            $insertValues[] = "1";
        }
        
        // Build and execute the query
        if (!empty($insertFields)) {
            $insertPayrollQuery = "INSERT INTO payroll (" . implode(", ", $insertFields) . ") 
                                   VALUES (" . implode(", ", $insertValues) . ")";
            
            $stmt = $conn->prepare($insertPayrollQuery);
            
            // Only bind parameters if we have any
            if (!empty($paramValues)) {
                $stmt->bind_param($paramTypes, ...$paramValues);
            }
            
            if ($stmt->execute()) {
                // Retrieve the generated payroll ID
                $payrollId = $conn->insert_id;
            } else {
                // If insert fails, try an alternative approach - insert only employee_id
                error_log("Payroll insert failed: " . $stmt->error);
                
                // Try a minimal insert with just employee_id if other columns have defaults
                $minimalQuery = "INSERT INTO payroll (employee_id) VALUES (?)";
                $stmt = $conn->prepare($minimalQuery);
                $stmt->bind_param("i", $employeeId);
                
                if ($stmt->execute()) {
                    $payrollId = $conn->insert_id;
                } else {
                    // Last resort - try to get existing payroll ID or create without constraints
                    error_log("Minimal payroll insert failed: " . $stmt->error);
                    $payrollId = null;
                }
            }
        } else {
            $payrollId = null;
        }
    } else {
        // Get the existing payroll ID if it exists
        $payrollId = $payrollResult->fetch_assoc()['id'];
    }

    // Only proceed if we have a valid payroll ID
    if ($payrollId) {
        // Fetch salary details - Calculate monthly salary from daily_salary or hourly_rate
        $salaryDetailsQuery = "
        SELECT 
            e.id, 
            CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
            e.contact_num, 
            e.position, 
            e.daily_salary,
            e.hourly_rate,
            CASE 
                WHEN e.daily_salary > 0 THEN e.daily_salary * " . WORKING_DAYS_PER_MONTH . "
                WHEN e.hourly_rate > 0 THEN e.hourly_rate * " . HOURS_PER_DAY . " * " . WORKING_DAYS_PER_MONTH . "
                ELSE 0
            END AS monthly_salary,
            CASE 
                WHEN e.daily_salary > 0 THEN (e.daily_salary * " . WORKING_DAYS_PER_MONTH . " - COALESCE(SUM(d.amount), 0))
                WHEN e.hourly_rate > 0 THEN (e.hourly_rate * " . HOURS_PER_DAY . " * " . WORKING_DAYS_PER_MONTH . " - COALESCE(SUM(d.amount), 0))
                ELSE 0
            END AS net_salary, 
            e.email, 
            sm.site_name, 
            sm.site_manager, 
            sm.site_address,
            COALESCE(SUM(d.amount), 0) AS total_deductions,
            p.id AS payroll_id,
            p.date_from,
            p.date_to
        FROM employees e
        LEFT JOIN site_employee se ON e.id = se.employee_id
        LEFT JOIN site_monitoring sm ON se.site_id = sm.id
        LEFT JOIN deduction d ON e.id = d.employee_id AND d.status = 'active'
        LEFT JOIN payroll p ON e.id = p.employee_id
        WHERE e.id = ? 
        AND p.id = ? 
        AND e.status = 'active'
        GROUP BY e.id, p.id, sm.id
    ";

        $stmt = $conn->prepare($salaryDetailsQuery);
        $stmt->bind_param("ii", $employeeId, $payrollId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $employeeData = $result->fetch_assoc();
        }

        // Fetch all deductions for the employee
        $deductionsQuery = "
        SELECT d.deduction_name, d.amount, d.status
        FROM deduction d
        WHERE d.employee_id = ? AND d.status != 'disabled'
    ";

        $stmt = $conn->prepare($deductionsQuery);
        $stmt->bind_param("i", $employeeId);
        $stmt->execute();
        $deductionsResult = $stmt->get_result();

        while ($row = $deductionsResult->fetch_assoc()) {
            $deductionsData[] = $row;
        }
    } else {
        // If we couldn't create a payroll record, try to fetch employee data without payroll join
        $salaryDetailsQuery = "
        SELECT 
            e.id, 
            CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
            e.contact_num, 
            e.position, 
            e.daily_salary,
            e.hourly_rate,
            CASE 
                WHEN e.daily_salary > 0 THEN e.daily_salary * " . WORKING_DAYS_PER_MONTH . "
                WHEN e.hourly_rate > 0 THEN e.hourly_rate * " . HOURS_PER_DAY . " * " . WORKING_DAYS_PER_MONTH . "
                ELSE 0
            END AS monthly_salary,
            CASE 
                WHEN e.daily_salary > 0 THEN (e.daily_salary * " . WORKING_DAYS_PER_MONTH . " - COALESCE(SUM(d.amount), 0))
                WHEN e.hourly_rate > 0 THEN (e.hourly_rate * " . HOURS_PER_DAY . " * " . WORKING_DAYS_PER_MONTH . " - COALESCE(SUM(d.amount), 0))
                ELSE 0
            END AS net_salary, 
            e.email, 
            sm.site_name, 
            sm.site_manager, 
            sm.site_address,
            COALESCE(SUM(d.amount), 0) AS total_deductions,
            NULL AS payroll_id,
            DATE_FORMAT(NOW(), '%Y-%m-01') AS date_from,
            LAST_DAY(NOW()) AS date_to
        FROM employees e
        LEFT JOIN site_employee se ON e.id = se.employee_id
        LEFT JOIN site_monitoring sm ON se.site_id = sm.id
        LEFT JOIN deduction d ON e.id = d.employee_id AND d.status = 'active'
        WHERE e.id = ? 
        AND e.status = 'active'
        GROUP BY e.id, sm.id
    ";

        $stmt = $conn->prepare($salaryDetailsQuery);
        $stmt->bind_param("i", $employeeId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $employeeData = $result->fetch_assoc();
            
            // Now try to create a payroll record with minimal fields
            if (in_array('employee_id', $payrollColumns)) {
                $minimalQuery = "INSERT INTO payroll (employee_id) VALUES (?)";
                $stmt2 = $conn->prepare($minimalQuery);
                $stmt2->bind_param("i", $employeeId);
                if ($stmt2->execute()) {
                    $payrollId = $conn->insert_id;
                    $employeeData['payroll_id'] = $payrollId;
                }
            }
        }

        // Fetch all deductions for the employee
        $deductionsQuery = "
        SELECT d.deduction_name, d.amount, d.status
        FROM deduction d
        WHERE d.employee_id = ? AND d.status != 'disabled'
    ";

        $stmt = $conn->prepare($deductionsQuery);
        $stmt->bind_param("i", $employeeId);
        $stmt->execute();
        $deductionsResult = $stmt->get_result();

        while ($row = $deductionsResult->fetch_assoc()) {
            $deductionsData[] = $row;
        }
    }
}

// Handle disabling an employee
if (isset($_POST['disable_employee_id'])) {
    $disableEmployeeId = $_POST['disable_employee_id'];

    // Update the status of the employee in the deductions table to 'disabled'
    $updateStatusQuery = "
        UPDATE deduction 
        SET status = 'disabled' 
        WHERE employee_id = ?
    ";
    $stmt = $conn->prepare($updateStatusQuery);
    $stmt->bind_param("i", $disableEmployeeId);
    $stmt->execute();

    // Redirect back to the salary slip page
    header("Location: salarySlip.php");
    exit;
}

// Get all employees with their site assignments for the main table - Calculate monthly salary
$salaryDetailsQuery = "
    SELECT 
        e.id, 
        CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
        e.position,
        e.daily_salary,
        e.hourly_rate,
        CASE 
            WHEN e.daily_salary > 0 THEN e.daily_salary * " . WORKING_DAYS_PER_MONTH . "
            WHEN e.hourly_rate > 0 THEN e.hourly_rate * " . HOURS_PER_DAY . " * " . WORKING_DAYS_PER_MONTH . "
            ELSE 0
        END AS monthly_salary,
        CASE 
            WHEN e.daily_salary > 0 THEN (e.daily_salary * " . WORKING_DAYS_PER_MONTH . " - COALESCE(SUM(d.amount), 0))
            WHEN e.hourly_rate > 0 THEN (e.hourly_rate * " . HOURS_PER_DAY . " * " . WORKING_DAYS_PER_MONTH . " - COALESCE(SUM(d.amount), 0))
            ELSE 0
        END AS net_salary, 
        COALESCE(SUM(d.amount), 0) AS total_deductions,
        sm.site_name
    FROM employees e
    LEFT JOIN deduction d ON e.id = d.employee_id AND d.status != 'disabled'
    LEFT JOIN site_employee se ON e.id = se.employee_id
    LEFT JOIN site_monitoring sm ON se.site_id = sm.id
    WHERE e.status = 'active'
    GROUP BY e.id, sm.id
    ORDER BY e.first_name, e.last_name
";
$result = $conn->query($salaryDetailsQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary Slip</title>
    <link rel="stylesheet" href="./assets/css/salarySlip2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-beta4/html2canvas.min.js"></script>
    <style>
        .content-wrapper {
            min-height: calc(100vh - var(--header-height) - 40px);
        }
        
        .employee-info {
            display: grid;
            gap: 4px;
        }
        
        .employee-info strong {
            color: var(--sidebar-dark-green);
            font-weight: 600;
        }
        
        .net-pay-cell {
            font-weight: 700;
            color: var(--success-color);
        }
        
        .deductions-cell {
            color: var(--danger-color);
        }
        
        .controls-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px 0;
            padding: 15px 20px;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }
        
        .search-section {
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 1;
        }
        
        .generate-report-btn {
            background-color: var(--sidebar-green);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: var(--box-shadow);
            white-space: nowrap;
            text-decoration: none;
        }
        
        .generate-report-btn:hover {
            background-color: var(--sidebar-dark-green);
            transform: translateY(-2px);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        }
        
        .pay-period {
            color: #666;
            font-size: 0.9rem;
            font-style: italic;
        }
        
        .site-info-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 10px;
            background-color: var(--light-green);
            color: var(--sidebar-dark-green);
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-top: 5px;
        }
        
        .site-info-badge i {
            color: var(--sidebar-green);
        }
        
        .salary-type-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 600;
            margin-left: 5px;
        }
        
        .daily-rate-badge {
            background-color: #e3f2fd;
            color: #1976d2;
        }
        
        .hourly-rate-badge {
            background-color: #fff3e0;
            color: #f57c00;
        }

        /* Toast Notification Styles */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .toast {
            min-width: 300px;
            max-width: 400px;
            background: white;
            border-radius: 8px;
            padding: 16px 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease;
            border-left: 4px solid;
        }

        .toast.success {
            border-left-color: #28a745;
        }

        .toast.success i {
            color: #28a745;
        }

        .toast.error {
            border-left-color: #dc3545;
        }

        .toast.error i {
            color: #dc3545;
        }

        .toast.warning {
            border-left-color: #ffc107;
        }

        .toast.warning i {
            color: #ffc107;
        }

        .toast.info {
            border-left-color: #17a2b8;
        }

        .toast.info i {
            color: #17a2b8;
        }

        .toast i {
            font-size: 1.2rem;
        }

        .toast-content {
            flex: 1;
            font-size: 0.95rem;
            color: #333;
        }

        .toast-close {
            background: none;
            border: none;
            color: #999;
            cursor: pointer;
            font-size: 1rem;
            padding: 0;
            transition: color 0.3s;
        }

        .toast-close:hover {
            color: #333;
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOut {
            from {
                transform: translateX(100%);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }

        /* Report Modal Styles */
        .report-modal {
            display: none;
            position: fixed;
            z-index: 10000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            align-items: center;
            justify-content: center;
        }

        .report-modal-content {
            background-color: #fff;
            margin: auto;
            padding: 0;
            border-radius: 12px;
            width: 95%;
            max-width: 1400px;
            height: 90vh;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            animation: modalFadeIn 0.3s;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .report-modal-header {
            padding: 20px 25px;
            background: linear-gradient(135deg, #2E7D32, #1B5E20);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 12px 12px 0 0;
        }

        .report-modal-header h3 {
            margin: 0;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .report-modal-header button {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 1.2rem;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .report-modal-header button:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: rotate(90deg);
        }

        .report-modal-body {
            padding: 25px;
            overflow-y: auto;
            flex: 1;
        }

        .report-summary-cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .report-summary-card {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            border-left: 4px solid #2E7D32;
        }

        .report-summary-card .label {
            font-size: 14px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .report-summary-card .value {
            font-size: 28px;
            font-weight: bold;
            color: #2E7D32;
            margin-top: 10px;
        }

        .report-table-container {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        .report-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        .report-table th {
            background: linear-gradient(135deg, #2E7D32, #1B5E20);
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .report-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #ddd;
        }

        .report-table tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        .report-table tr:hover {
            background-color: #f1f8e9;
        }

        .report-table .text-right {
            text-align: right;
        }

        .report-table .currency {
            font-weight: 600;
        }

        .report-table .total-row {
            background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
            font-weight: bold;
        }

        .report-table .total-row td {
            border-top: 2px solid #2E7D32;
            padding: 12px;
        }

        .report-site-badge {
            display: inline-block;
            padding: 4px 10px;
            background: #e8f5e9;
            color: #2E7D32;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
        }

        .report-footer {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 2px solid #2E7D32;
            display: flex;
            justify-content: space-between;
            color: #666;
            font-size: 14px;
        }

        .report-print-btn {
            background: linear-gradient(135deg, #2E7D32, #1B5E20);
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 25px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .report-print-btn:hover {
            background: linear-gradient(135deg, #1B5E20, #0D4510);
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(46, 125, 50, 0.3);
        }

        .report-loading {
            text-align: center;
            padding: 50px;
            color: #666;
        }

        .report-loading i {
            font-size: 3rem;
            color: #2E7D32;
            margin-bottom: 15px;
        }

        @keyframes modalFadeIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media print {
            body * {
                visibility: hidden;
            }
            .report-modal-content, .report-modal-content * {
                visibility: visible;
            }
            .report-modal-content {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                height: auto;
                box-shadow: none;
            }
            .report-modal-header, .report-print-btn {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Toast Container -->
    <div id="toastContainer" class="toast-container"></div>

    <!-- Header -->
    <?php include_once("./includes/header.php"); ?>

    <main class="content">
        <div class="content-wrapper">
            
            <!-- Search Controls - KEPT ORIGINAL -->
            <div class="controls">
                <div class="search-container">
                    <input type="text" placeholder="Search employees..." class="search-bar" id="searchEmployee">
                    <button class="search-btn" onclick="searchEmployees()">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>

            <!-- Generate Report Button - FIXED -->
            <button class="generate-report-btn" onclick="showReportModal()" style="margin: 20px 0; display: inline-block;">
                <i class="fas fa-chart-bar"></i> Generate Salary Report
            </button>

            <!-- Salary Table - UPDATED: Added Site Assignment column -->
            <div class="table-responsive">
                <table class="form-container" id="salaryTable">
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>Employee Name</th>
                            <th>Position</th>
                            <th>Site Assignment</th>
                            <th>Monthly Salary</th>
                            <th>Total Deductions</th>
                            <th>Net Salary</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && $result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                            <tr class="employee-row">
                                <td><strong><?= $row['id'] ?></strong></td>
                                <td>
                                    <div class="employee-info">
                                        <div><strong>Name:</strong> <?= htmlspecialchars($row['employee_name']) ?></div>
                                        <?php if ($row['daily_salary'] > 0): ?>
                                            <span class="salary-type-badge daily-rate-badge">Daily Rate: ₱<?= number_format($row['daily_salary'], 2) ?></span>
                                        <?php elseif ($row['hourly_rate'] > 0): ?>
                                            <span class="salary-type-badge hourly-rate-badge">Hourly Rate: ₱<?= number_format($row['hourly_rate'], 2) ?></span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars($row['position']) ?></td>
                                <td>
                                    <?php if (!empty($row['site_name'])): ?>
                                        <div class="site-info-badge">
                                            <i class="fas fa-map-marked-alt"></i>
                                            <?= htmlspecialchars($row['site_name']) ?>
                                        </div>
                                    <?php else: ?>
                                        <span style="color: #999; font-style: italic;">Not assigned</span>
                                    <?php endif; ?>
                                </td>
                                <td class="currency">₱<?= number_format($row['monthly_salary'], 2) ?></td>
                                <td class="currency deductions-cell">₱<?= number_format($row['total_deductions'], 2) ?></td>
                                <td class="currency net-pay-cell">₱<?= number_format($row['net_salary'], 2) ?></td>
                                <td>
                                    <a href="salarySlip.php?employee_id=<?= $row['id'] ?>" class="view" title="View Salary Slip">
                                        <i class="fas fa-eye"></i> View Slip
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8">
                                    <div class="empty-state">
                                        <i class="fas fa-file-invoice-dollar"></i>
                                        <p>No salary data found</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include_once("./includes/footer.php"); ?>

    <!-- Salary Slip Modal -->
    <?php if ($employeeData): ?>
    <div id="salary-modal" class="salary-modal">
        <div class="salary-modal-content" id="salary-slip-content">
            <div class="salary-header">
                <h2><i class="fas fa-file-invoice-dollar"></i> SALARY SLIP</h2>
                <p>
                    <?= date('F Y') ?> • 
                    Pay Period: 
                    <?php 
                    if (!empty($employeeData['date_from']) && $employeeData['date_from'] != '0000-00-00') {
                        echo date('M d', strtotime($employeeData['date_from']));
                    } else {
                        echo date('M 01');
                    }
                    ?> - 
                    <?php 
                    if (!empty($employeeData['date_to']) && $employeeData['date_to'] != '0000-00-00') {
                        echo date('M d, Y', strtotime($employeeData['date_to']));
                    } else {
                        echo date('M t, Y');
                    }
                    ?>
                </p>
            </div>
            
            <div class="employee-info-modal">
                <div>
                    <strong><i class="fas fa-id-card"></i> Employee ID:</strong>
                    <span><?= htmlspecialchars($employeeData['id']) ?></span>
                </div>
                <div>
                    <strong><i class="fas fa-user"></i> Employee Name:</strong>
                    <span><?= htmlspecialchars($employeeData['employee_name']) ?></span>
                </div>
                <div>
                    <strong><i class="fas fa-briefcase"></i> Position:</strong>
                    <span><?= htmlspecialchars($employeeData['position']) ?></span>
                </div>
                <div>
                    <strong><i class="fas fa-map-marked-alt"></i> Site:</strong>
                    <span><?= htmlspecialchars($employeeData['site_name'] ?? 'Not Assigned') ?></span>
                </div>
                <?php if (!empty($employeeData['site_manager'])): ?>
                <div>
                    <strong><i class="fas fa-user-tie"></i> Site Manager:</strong>
                    <span><?= htmlspecialchars($employeeData['site_manager']) ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($employeeData['site_address'])): ?>
                <div style="grid-column: span 2;">
                    <strong><i class="fas fa-map-marker-alt"></i> Site Address:</strong>
                    <span><?= htmlspecialchars($employeeData['site_address']) ?></span>
                </div>
                <?php endif; ?>
                <div>
                    <strong><i class="fas fa-calculator"></i> Rate Type:</strong>
                    <span>
                        <?php if ($employeeData['daily_salary'] > 0): ?>
                            Daily (₱<?= number_format($employeeData['daily_salary'], 2) ?>/day)
                        <?php elseif ($employeeData['hourly_rate'] > 0): ?>
                            Hourly (₱<?= number_format($employeeData['hourly_rate'], 2) ?>/hour)
                        <?php endif; ?>
                    </span>
                </div>
            </div>

            <table class="salary-table">
                <thead>
                    <tr>
                        <th>Earnings</th>
                        <th>Amount</th>
                        <th>Deductions</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Base Salary</strong></td>
                        <td class="currency">₱<?= number_format($employeeData['monthly_salary'], 2) ?></td>
                        <td>
                            <?php if (count($deductionsData) > 0): ?>
                                <?php foreach ($deductionsData as $index => $deduction): ?>
                                    <?php if ($deduction['status'] !== 'disabled'): ?>
                                        <div><?= htmlspecialchars($deduction['deduction_name']) ?></div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div>-</div>
                            <?php endif; ?>
                        </td>
                        <td class="currency">
                            <?php if (count($deductionsData) > 0): ?>
                                <?php foreach ($deductionsData as $deduction): ?>
                                    <?php if ($deduction['status'] !== 'disabled'): ?>
                                        <div>₱<?= number_format($deduction['amount'], 2) ?></div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div>-</div>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Total Earnings</strong></td>
                        <td class="currency">₱<?= number_format($employeeData['monthly_salary'], 2) ?></td>
                        <td><strong>Total Deductions</strong></td>
                        <td class="currency deductions-cell">₱<?= number_format($employeeData['total_deductions'], 2) ?></td>
                    </tr>
                </tbody>
            </table>
            
            <div class="net-pay">
                <i class="fas fa-money-check-alt"></i> 
                <strong>NET PAY: ₱<?= number_format($employeeData['net_salary'], 2) ?></strong>
            </div>

            <div class="modal-buttons">
                <button class="close-btn" onclick="closeModal()">
                    <i class="fas fa-times"></i> Close
                </button>
                <button class="send-btn" onclick="saveAsImage()">
                    <i class="fas fa-download"></i> Save as Image
                </button>
            </div>
        </div>
    </div>
    
    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loading-spinner"></div>
        <p>Saving salary slip...</p>
    </div>
    
    <!-- Download Success Message -->
    <div class="download-success" id="downloadSuccess">
        <i class="fas fa-check-circle"></i> Salary slip saved successfully!
    </div>
    <?php endif; ?>

    <!-- Report Modal -->
    <div id="reportModal" class="report-modal">
        <div class="report-modal-content">
            <div class="report-modal-header">
                <h3><i class="fas fa-chart-bar"></i> Salary Report</h3>
                <button onclick="closeReportModal()"><i class="fas fa-times"></i></button>
            </div>
            <div class="report-modal-body" id="reportModalBody">
                <div class="report-loading" id="reportLoading">
                    <i class="fas fa-spinner fa-spin"></i>
                    <p>Generating report...</p>
                </div>
                <div id="reportContent" style="display: none;"></div>
            </div>
        </div>
    </div>
    
    <?php include_once("./modal/logout-modal.php"); ?>

    <script>
        // Ensure the modal opens automatically if the page is loaded with an employee ID
        document.addEventListener('DOMContentLoaded', function() {
            <?php if ($employeeData): ?>
                document.getElementById('salary-modal').style.display = 'flex';
                document.body.classList.add('modal-open');
            <?php endif; ?>
            
            // Check for toast messages
            const toastMessage = localStorage.getItem('toastMessage');
            const toastType = localStorage.getItem('toastType');
            
            if (toastMessage) {
                showToast(toastMessage, toastType || 'success');
                localStorage.removeItem('toastMessage');
                localStorage.removeItem('toastType');
            }
        });

        // Toast notification function
        function showToast(message, type = 'success', duration = 5000) {
            const container = document.getElementById('toastContainer');
            if (!container) return;
            
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            
            let icon = '';
            switch(type) {
                case 'success':
                    icon = '<i class="fas fa-check-circle"></i>';
                    break;
                case 'error':
                    icon = '<i class="fas fa-exclamation-circle"></i>';
                    break;
                case 'warning':
                    icon = '<i class="fas fa-exclamation-triangle"></i>';
                    break;
                default:
                    icon = '<i class="fas fa-info-circle"></i>';
            }
            
            toast.innerHTML = `
                ${icon}
                <div class="toast-content">${message}</div>
                <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
            `;
            
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    if (toast.parentElement) {
                        toast.remove();
                    }
                }, 300);
            }, duration);
        }

        // Close the salary slip modal
        function closeModal() {
            document.getElementById('salary-modal').style.display = 'none';
            document.body.classList.remove('modal-open');
            window.history.pushState({}, document.title, window.location.pathname);
        }

        // Function to save the salary slip as an image
        function saveAsImage() {
            var salarySlipContent = document.getElementById('salary-slip-content');
            var modalButtons = document.querySelector('.modal-buttons');
            var loadingOverlay = document.getElementById('loadingOverlay');

            // Show loading overlay
            loadingOverlay.style.display = 'flex';
            
            // Hide buttons temporarily
            modalButtons.style.display = 'none';

            html2canvas(salarySlipContent, {
                scale: 3,
                useCORS: true,
                backgroundColor: '#ffffff',
                onclone: function(clonedDoc) {
                    clonedDoc.querySelector('.modal-buttons').style.display = 'none';
                }
            }).then(function(canvas) {
                // Convert canvas to image
                var link = document.createElement('a');
                link.href = canvas.toDataURL('image/png', 1.0);
                link.download = `Salary_Slip_${<?= $employeeData['id'] ?? '0' ?>}_<?= date('Y_m_d') ?>.png`;

                // Trigger download
                link.click();

                // Restore buttons
                modalButtons.style.display = 'flex';
                loadingOverlay.style.display = 'none';
                
                // Show success message
                showDownloadSuccess();
            }).catch(function(error) {
                console.error('Error capturing salary slip:', error);
                modalButtons.style.display = 'flex';
                loadingOverlay.style.display = 'none';
                alert('Error saving salary slip. Please try again.');
            });
        }

        // Show download success message
        function showDownloadSuccess() {
            const successMsg = document.getElementById('downloadSuccess');
            successMsg.style.display = 'block';
            setTimeout(() => {
                successMsg.style.display = 'none';
            }, 3000);
        }

        // Search functionality
        function searchEmployees() {
            const searchTerm = document.getElementById('searchEmployee').value.toLowerCase();
            const rows = document.querySelectorAll('.employee-row');
            
            rows.forEach(row => {
                const employeeName = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                const employeeId = row.querySelector('td:nth-child(1)').textContent.toLowerCase();
                const siteName = row.querySelector('td:nth-child(4)') ? row.querySelector('td:nth-child(4)').textContent.toLowerCase() : '';
                
                if (employeeName.includes(searchTerm) || employeeId.includes(searchTerm) || siteName.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        // Enter key for search
        document.getElementById('searchEmployee').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchEmployees();
            }
        });

        // Close modal when clicking outside
        window.onclick = function(event) {
            const salaryModal = document.getElementById('salary-modal');
            const reportModal = document.getElementById('reportModal');
            
            if (event.target === salaryModal) {
                closeModal();
            }
            if (event.target === reportModal) {
                closeReportModal();
            }
        }

        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeModal();
                closeReportModal();
            }
        });

        // Report Modal Functions
        function showReportModal() {
            document.getElementById('reportModal').style.display = 'flex';
            document.body.classList.add('modal-open');
            
            // Show loading, hide content
            document.getElementById('reportLoading').style.display = 'block';
            document.getElementById('reportContent').style.display = 'none';
            
            // Generate report data
            generateReportData();
        }

        function closeReportModal() {
            document.getElementById('reportModal').style.display = 'none';
            document.body.classList.remove('modal-open');
        }

        function generateReportData() {
            // Get current date range (first and last day of current month)
            const today = new Date();
            const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
            const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
            
            const formatDate = (date) => {
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                return `${year}-${month}-${day}`;
            };
            
            // Make AJAX request to get report data
            fetch('salarySlip.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `ajax=generate_report&date_from=${formatDate(firstDay)}&date_to=${formatDate(lastDay)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    displayReport(data);
                } else {
                    showToast('Error generating report', 'error');
                    closeReportModal();
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Error generating report', 'error');
                closeReportModal();
            });
        }

        function displayReport(data) {
            const reportContent = document.getElementById('reportContent');
            const reportLoading = document.getElementById('reportLoading');
            
            let html = `
                <div class="report-summary-cards">
                    <div class="report-summary-card">
                        <div class="label">Total Employees</div>
                        <div class="value">${data.totals.count}</div>
                    </div>
                    <div class="report-summary-card">
                        <div class="label">Gross Salary</div>
                        <div class="value">₱${formatNumber(data.totals.gross)}</div>
                    </div>
                    <div class="report-summary-card">
                        <div class="label">Total Deductions</div>
                        <div class="value">₱${formatNumber(data.totals.deductions)}</div>
                    </div>
                    <div class="report-summary-card">
                        <div class="label">Net Payroll</div>
                        <div class="value">₱${formatNumber(data.totals.net)}</div>
                    </div>
                </div>
                
                <div style="margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;">
                    <h4 style="color: #2E7D32; margin: 0;">
                        <i class="fas fa-calendar-alt"></i> Period: ${data.date_from} to ${data.date_to}
                    </h4>
                    <button class="report-print-btn" onclick="printReport()">
                        <i class="fas fa-print"></i> Print / Save as PDF
                    </button>
                </div>
                
                <div class="report-table-container">
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Employee Name</th>
                                <th>Position</th>
                                <th>Site</th>
                                <th class="text-right">Monthly Salary</th>
                                <th class="text-right">Deductions</th>
                                <th class="text-right">Net Salary</th>
                            </tr>
                        </thead>
                        <tbody>
            `;
            
            if (data.employees.length > 0) {
                data.employees.forEach(emp => {
                    html += `
                        <tr>
                            <td><strong>${String(emp.id).padStart(4, '0')}</strong></td>
                            <td>${escapeHtml(emp.employee_name)}</td>
                            <td>${escapeHtml(emp.position)}</td>
                            <td>
                                ${emp.site_name ? 
                                    `<span class="report-site-badge">${escapeHtml(emp.site_name)}</span>` : 
                                    '<span style="color: #999;">Not assigned</span>'}
                            </td>
                            <td class="text-right currency">₱${formatNumber(emp.monthly_salary)}</td>
                            <td class="text-right currency" style="color: #dc3545;">₱${formatNumber(emp.total_deductions)}</td>
                            <td class="text-right currency" style="color: #2E7D32; font-weight: bold;">₱${formatNumber(emp.net_salary)}</td>
                        </tr>
                    `;
                });
                
                // Totals row
                html += `
                    <tr class="total-row">
                        <td colspan="4" class="text-right"><strong>GRAND TOTALS:</strong></td>
                        <td class="text-right"><strong>₱${formatNumber(data.totals.gross)}</strong></td>
                        <td class="text-right"><strong>₱${formatNumber(data.totals.deductions)}</strong></td>
                        <td class="text-right"><strong>₱${formatNumber(data.totals.net)}</strong></td>
                    </tr>
                `;
            } else {
                html += `
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px;">
                            <i class="fas fa-file-invoice" style="font-size: 48px; color: #ccc; margin-bottom: 10px;"></i>
                            <p style="color: #666;">No salary data found for the selected period.</p>
                        </td>
                    </tr>
                `;
            }
            
            html += `
                        </tbody>
                    </table>
                </div>
                
                <div class="report-footer">
                    <div><strong>Generated on:</strong> ${new Date().toLocaleString()}</div>
                    <div><strong>Generated by:</strong> <?= $_SESSION['Admin_User'] ?></div>
                    <div><strong>Report ID:</strong> SAL-${new Date().toISOString().slice(0,10).replace(/-/g,'')}-${Math.floor(Math.random() * 1000)}</div>
                </div>
            `;
            
            reportContent.innerHTML = html;
            reportLoading.style.display = 'none';
            reportContent.style.display = 'block';
        }

        function formatNumber(num) {
            return new Intl.NumberFormat('en-PH', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }).format(num);
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function printReport() {
            window.print();
        }
    </script>

</body>
</html>