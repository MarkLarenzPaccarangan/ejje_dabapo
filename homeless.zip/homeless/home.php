<?php
// Start session
session_start();

// TURN ON ERROR DISPLAY - PARA MAKITA ANG ACTUAL ERROR
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

// Include access control - with error handling
$access_control_loaded = false;
if (file_exists("check_access.php")) {
    include_once("check_access.php");
    $access_control_loaded = true;
} else {
    // Log that file is missing but continue
    error_log("check_access.php not found - continuing without access control");
}

// Check if user has access to this page (only if access control is loaded)
$current_page = basename($_SERVER['PHP_SELF']);
if ($access_control_loaded && function_exists('checkPageAccess') && !checkPageAccess($current_page)) {
    header("Location: home.php?error=access_denied");
    exit;
}
// If access control not loaded, proceed without checking (for now)

// Include database connection
include_once("connection.php");

// ============================================
// DASHBOARD FUNCTIONS
// ============================================

/**
 * Get sites with employee counts and attendance for a specific date - FIXED VERSION
 * Now properly counts employees as present if they have EITHER AM OR PM presence
 */
function getSitesWithAttendance($conn, $filter_date = null, $search = '', $sort_by = 'site_name', $sort_order = 'ASC') {
    if (!$filter_date) {
        $filter_date = date('Y-m-d');
    }
    
    $valid_sort_columns = ['site_name', 'site_manager', 'site_address', 'id', 'total_employees', 'present_count', 'absent_count', 'leave_count', 'attendance_rate'];
    if (!in_array($sort_by, $valid_sort_columns)) {
        $sort_by = 'site_name';
    }
    $sort_order = strtoupper($sort_order) === 'DESC' ? 'DESC' : 'ASC';
    
    // SIMPLIFIED QUERY - kunin muna ang site_monitoring data
    $query = "SELECT 
                s.id,
                s.site_name,
                s.site_manager,
                s.site_address,
                s.is_others,
                (SELECT COUNT(*) FROM site_employee se WHERE se.site_id = s.id AND se.status = 'active') as total_employees,
                0 as present_count,
                0 as absent_count,
                0 as leave_count,
                0 as attendance_rate
              FROM site_monitoring s
              WHERE 1=1";
    
    $params = [];
    $types = "";
    
    if (!empty($search)) {
        $query .= " AND (s.site_name LIKE ? OR s.site_manager LIKE ? OR s.site_address LIKE ?)";
        $search_term = '%' . $search . '%';
        $params = [$search_term, $search_term, $search_term];
        $types = "sss";
    }
    
    // Handle sorting
    switch ($sort_by) {
        case 'site_name':
            $query .= " ORDER BY s.site_name $sort_order";
            break;
        case 'site_manager':
            $query .= " ORDER BY s.site_manager $sort_order";
            break;
        case 'site_address':
            $query .= " ORDER BY s.site_address $sort_order";
            break;
        case 'id':
            $query .= " ORDER BY s.id $sort_order";
            break;
        default:
            $query .= " ORDER BY s.site_name $sort_order";
    }
    
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        error_log("Error preparing query: " . $conn->error);
        return [];
    }
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $sites = [];
    while ($row = $result->fetch_assoc()) {
        // FIXED: Get actual present count for this date
        $present_query = "SELECT COUNT(DISTINCT a.employee_id) as present_count 
                          FROM attendance a 
                          INNER JOIN site_employee se ON a.employee_id = se.employee_id 
                          WHERE se.site_id = ? AND a.date = ? 
                          AND (a.status_am = 'Present' OR a.status_pm = 'Present')";
        $present_stmt = $conn->prepare($present_query);
        if ($present_stmt) {
            $present_stmt->bind_param("is", $row['id'], $filter_date);
            $present_stmt->execute();
            $present_result = $present_stmt->get_result();
            if ($present_row = $present_result->fetch_assoc()) {
                $row['present_count'] = intval($present_row['present_count']);
            }
            $present_stmt->close();
        }
        
        // NEW: Get leave count for this date
        $leave_query = "SELECT COUNT(DISTINCT a.employee_id) as leave_count 
                        FROM attendance a 
                        INNER JOIN site_employee se ON a.employee_id = se.employee_id 
                        WHERE se.site_id = ? AND a.date = ? 
                        AND (a.status_am = 'On Leave' OR a.status_pm = 'On Leave')";
        $leave_stmt = $conn->prepare($leave_query);
        if ($leave_stmt) {
            $leave_stmt->bind_param("is", $row['id'], $filter_date);
            $leave_stmt->execute();
            $leave_result = $leave_stmt->get_result();
            if ($leave_row = $leave_result->fetch_assoc()) {
                $row['leave_count'] = intval($leave_row['leave_count']);
            }
            $leave_stmt->close();
        }
        
        // Calculate absent count
        $row['absent_count'] = max(0, $row['total_employees'] - $row['present_count'] - $row['leave_count']);
        
        // Calculate attendance rate
        if ($row['total_employees'] > 0) {
            $row['attendance_rate'] = round(($row['present_count'] / $row['total_employees']) * 100);
        } else {
            $row['attendance_rate'] = 0;
        }
        
        // Get others details if needed
        if ($row['is_others'] == 1) {
            $others_query = "SELECT assignment_type, person_group FROM site_others WHERE site_id = ?";
            $others_stmt = $conn->prepare($others_query);
            if ($others_stmt) {
                $others_stmt->bind_param("i", $row['id']);
                $others_stmt->execute();
                $others_result = $others_stmt->get_result();
                if ($others_row = $others_result->fetch_assoc()) {
                    $row['assignment_type'] = $others_row['assignment_type'];
                    $row['person_group'] = $others_row['person_group'];
                }
                $others_stmt->close();
            }
        }
        $sites[] = $row;
    }
    
    return $sites;
}

/**
 * Get available dates for filter dropdown
 */
function getAvailableDates($conn) {
    $query = "SELECT DISTINCT date 
              FROM attendance 
              ORDER BY date DESC 
              LIMIT 30";
    $result = $conn->query($query);
    
    $dates = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $dates[] = $row['date'];
        }
    }
    
    return $dates;
}

/**
 * Get total statistics across all sites - FIXED to count AM or PM presence
 * NOW INCLUDES ON LEAVE COUNT
 */
function getTotalStats($conn, $filter_date = null) {
    if (!$filter_date) {
        $filter_date = date('Y-m-d');
    }
    
    $query = "SELECT 
                COUNT(*) as total_sites
              FROM site_monitoring";
    
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
    
    // Get total employees from site_employee (active only)
    $emp_query = "SELECT COUNT(DISTINCT employee_id) as total FROM site_employee WHERE status = 'active'";
    $emp_result = $conn->query($emp_query);
    $emp_row = $emp_result->fetch_assoc();
    
    // FIXED: Get present count for the date
    $present_query = "SELECT COUNT(DISTINCT employee_id) as total 
                      FROM attendance 
                      WHERE date = ? 
                      AND (status_am = 'Present' OR status_pm = 'Present')";
    $present_stmt = $conn->prepare($present_query);
    $present_stmt->bind_param("s", $filter_date);
    $present_stmt->execute();
    $present_result = $present_stmt->get_result();
    $present_row = $present_result->fetch_assoc();
    
    // NEW: Get on leave count for the date
    $leave_query = "SELECT COUNT(DISTINCT employee_id) as total 
                    FROM attendance 
                    WHERE date = ? 
                    AND (status_am = 'On Leave' OR status_pm = 'On Leave')";
    $leave_stmt = $conn->prepare($leave_query);
    $leave_stmt->bind_param("s", $filter_date);
    $leave_stmt->execute();
    $leave_result = $leave_stmt->get_result();
    $leave_row = $leave_result->fetch_assoc();
    
    // Calculate absent count
    $total_employees = $emp_row['total'] ?? 0;
    $total_present = $present_row['total'] ?? 0;
    $total_leave = $leave_row['total'] ?? 0;
    $total_absent = max(0, $total_employees - $total_present - $total_leave);
    
    return [
        'total_sites' => $row['total_sites'] ?? 0,
        'total_employees' => $total_employees,
        'total_present' => $total_present,
        'total_leave' => $total_leave,
        'total_absent' => $total_absent
    ];
}

/**
 * Get employees with attendance status for a specific site and date - FIXED with total_hours
 * Now properly displays AM and PM status separately
 */
function getSiteEmployeesWithAttendance($conn, $site_id, $filter_date = null) {
    if (!$filter_date) {
        $filter_date = date('Y-m-d');
    }
    
    $employees = [];
    
    $query = "SELECT 
                e.id,
                e.first_name,
                e.last_name,
                e.position,
                e.email,
                se.assigned_date,
                a.status_am,
                a.status_pm,
                a.time_in_am,
                a.time_out_am,
                a.time_in_pm,
                a.time_out_pm,
                a.remarks,
                a.total_hours,
                a.leave_type
              FROM employees e
              INNER JOIN site_employee se ON e.id = se.employee_id
              LEFT JOIN attendance a ON e.id = a.employee_id AND a.date = ?
              WHERE se.site_id = ? AND se.status = 'active'
              AND e.status = 'active' AND e.is_active = 1
              ORDER BY e.first_name, e.last_name";
    
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        error_log("Error preparing query: " . $conn->error);
        return $employees;
    }
    
    $stmt->bind_param("si", $filter_date, $site_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        // Set default values if NULL
        $row['status_am'] = $row['status_am'] ?? 'Absent';
        $row['status_pm'] = $row['status_pm'] ?? 'Absent';
        $row['time_in_am'] = $row['time_in_am'] ?? null;
        $row['time_out_am'] = $row['time_out_am'] ?? null;
        $row['time_in_pm'] = $row['time_in_pm'] ?? null;
        $row['time_out_pm'] = $row['time_out_pm'] ?? null;
        $row['total_hours'] = $row['total_hours'] ?? 0.00;
        $row['leave_type'] = $row['leave_type'] ?? '';
        
        $employees[] = $row;
    }
    
    return $employees;
}

// ============================================
// GET DASHBOARD DATA
// ============================================

// Get filter date from URL parameter or use today
$filter_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Validate date format
if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $filter_date)) {
    $filter_date = date('Y-m-d');
}

// Get search and sort parameters
$search_query = isset($_GET['search']) ? $_GET['search'] : '';
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'site_name';
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'ASC';

// Get site ID for employee view modal
$view_site_id = isset($_GET['view_site']) ? (int)$_GET['view_site'] : 0;
$view_employees = [];
$view_site_details = null;

if ($view_site_id > 0) {
    // Get site details
    $site_query = "SELECT s.*, so.assignment_type, so.person_group 
                   FROM site_monitoring s 
                   LEFT JOIN site_others so ON s.id = so.site_id 
                   WHERE s.id = ?";
    
    $stmt = $conn->prepare($site_query);
    $stmt->bind_param("i", $view_site_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $view_site_details = $result->fetch_assoc();
    
    // Get employees with attendance
    $view_employees = getSiteEmployeesWithAttendance($conn, $view_site_id, $filter_date);
}

// Fetch sites data with search and sort
$sites = getSitesWithAttendance($conn, $filter_date, $search_query, $sort_by, $sort_order);

// Fetch total statistics
$total_stats = getTotalStats($conn, $filter_date);

// Fetch available dates for filter
$available_dates = getAvailableDates($conn);

// Format display date
$display_date = date('m/d/Y', strtotime($filter_date));
$month = date('m', strtotime($filter_date));
$year = date('Y', strtotime($filter_date));
$day = date('d', strtotime($filter_date));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Site Monitoring</title>
    <link rel="stylesheet" href="./assets/css/home3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <!-- header -->
    <?php include_once("./includes/header.php"); ?>

    <main class="content">
        <div class="main-content">
            <div class="dashboard-container">
                <!-- Dashboard Header with Date Filter -->
                <div class="dashboard-header">
                    <div class="dashboard-title">
                        <i class="fas fa-chart-line"></i>
                        Dashboard
                    </div>
                    
                    <div class="date-filter">
                        <label>
                            <i class="fas fa-calendar-alt"></i>
                            Date:
                        </label>
                        
                        <div class="main-date-picker-wrapper">
                            <button type="button" class="main-date-picker-btn" onclick="toggleMainCalendar()">
                                
                                <span id="mainDateDisplay"><?= $display_date ?></span>
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <input type="hidden" id="selectedDate" name="date" value="<?= $filter_date ?>">
                            
                            <div class="main-calendar-wrapper" id="mainCalendarWrapper">
                                <div class="main-calendar-box">
                                    <div class="main-calendar-header">
                                        <div class="main-calendar-month-year" id="mainCalendarMonthYear">
                                            <?= date('F Y', strtotime($filter_date)) ?>
                                        </div>
                                        <div class="main-calendar-nav">
                                            <button type="button" class="main-calendar-nav-btn" onclick="navigateMainMonth(-1)">‹</button>
                                            <button type="button" class="main-calendar-nav-btn" onclick="navigateMainMonth(1)">›</button>
                                        </div>
                                    </div>
                                    
                                    <div class="main-calendar-selectors">
                                        <select id="mainMonthSelect" class="main-calendar-select" onchange="changeMainMonthYear()">
                                            <option value="0">January</option>
                                            <option value="1">February</option>
                                            <option value="2">March</option>
                                            <option value="3">April</option>
                                            <option value="4">May</option>
                                            <option value="5">June</option>
                                            <option value="6">July</option>
                                            <option value="7">August</option>
                                            <option value="8">September</option>
                                            <option value="9">October</option>
                                            <option value="10">November</option>
                                            <option value="11">December</option>
                                        </select>
                                        
                                        <select id="mainYearSelect" class="main-calendar-select" onchange="changeMainMonthYear()">
                                            <?php for($y = date('Y') - 10; $y <= date('Y') + 10; $y++): ?>
                                                <option value="<?= $y ?>" <?= $y == $year ? 'selected' : '' ?>><?= $y ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    
                                    <div class="main-calendar-weekdays">
                                        <div>Sun</div>
                                        <div>Mon</div>
                                        <div>Tue</div>
                                        <div>Wed</div>
                                        <div>Thu</div>
                                        <div>Fri</div>
                                        <div>Sat</div>
                                    </div>
                                    
                                    <div class="main-calendar-days-grid" id="mainCalendarDaysGrid">
                                        <!-- Days will be populated here by JavaScript -->
                                    </div>
                                    
                                    <div class="main-calendar-footer">
                                        <button type="button" class="main-calendar-action-btn clear" onclick="clearMainDate()">
                                            <i class="fas fa-times"></i> Clear
                                        </button>
                                        <button type="button" class="main-calendar-action-btn today" onclick="setMainToday()">
                                            <i class="fas fa-calendar-check"></i> Today
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if (!empty($available_dates)): ?>
                        <select id="quick_date" class="quick-select" onchange="quickDateSelect(this.value)">
                            <option value="">Quick Select</option>
                            <?php foreach ($available_dates as $date): ?>
                            <option value="<?php echo htmlspecialchars($date); ?>" <?php echo $date == $filter_date ? 'selected' : ''; ?>>
                                <?php echo date('M d, Y', strtotime($date)); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Statistics Cards - 6 cards now (Total Sites, Total Employees, Present, Absent, On Leave, Attendance Rate) -->
                <div class="stats-cards">
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Total Sites</h3>
                            <div class="number"><?php echo number_format($total_stats['total_sites'] ?? 0); ?></div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-building"></i>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Total Employees</h3>
                            <div class="number"><?php echo number_format($total_stats['total_employees'] ?? 0); ?></div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Present</h3>
                            <div class="number present">
                                <?php echo number_format($total_stats['total_present'] ?? 0); ?>
                            </div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                    </div>
                    
                    <!-- NEW: Absent Stat Card -->
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Absent</h3>
                            <div class="number absent">
                                <?php echo number_format($total_stats['total_absent'] ?? 0); ?>
                            </div>
                        </div>
                        <div class="stat-icon absent">
                            <i class="fas fa-times-circle"></i>
                        </div>
                    </div>
                    
                    <!-- On Leave Stat Card -->
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>On Leave</h3>
                            <div class="number leave">
                                <?php echo number_format($total_stats['total_leave'] ?? 0); ?>
                            </div>
                        </div>
                        <div class="stat-icon leave">
                            <i class="fas fa-umbrella-beach"></i>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Attendance Rate</h3>
                            <div class="number">
                                <?php 
                                $total_emp = $total_stats['total_employees'] ?? 0;
                                $total_present = $total_stats['total_present'] ?? 0;
                                $rate = $total_emp > 0 ? round(($total_present / $total_emp) * 100) : 0;
                                echo $rate . '%';
                                ?>
                            </div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-percentage"></i>
                        </div>
                    </div>
                </div>

                <!-- Sites Dashboard Section -->
                <div class="sites-container">
                    <div class="sites-header">
                        <h2>
                            <i class="fas fa-map-marked-alt"></i>
                            Site Status Overview
                        </h2>
                        <div class="sites-controls">
                            <!-- Search Bar -->
                            <div class="site-search-container">
                                <form method="GET" action="home.php" id="searchForm" style="display: flex; align-items: center; width: 100%;">
                                    <input type="hidden" name="date" value="<?php echo htmlspecialchars($filter_date); ?>">
                                    <input type="hidden" name="sort_by" value="<?php echo htmlspecialchars($sort_by); ?>">
                                    <input type="hidden" name="sort_order" value="<?php echo htmlspecialchars($sort_order); ?>">
                                    <input type="text" name="search" 
                                           value="<?php echo htmlspecialchars($search_query); ?>" 
                                           placeholder="Search sites..." 
                                           class="site-search-bar">
                                    <button type="submit" class="site-search-btn">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </form>
                            </div>
                            
                            <!-- Sort Controls -->
                            <div class="site-sort-container">
                                <form method="GET" action="home.php" id="sortForm" style="display: flex; align-items: center; gap: 8px;">
                                    <input type="hidden" name="date" value="<?php echo htmlspecialchars($filter_date); ?>">
                                    <input type="hidden" name="search" value="<?php echo htmlspecialchars($search_query); ?>">
                                    <select name="sort_by" class="site-sort-select" onchange="document.getElementById('sortForm').submit();">
                                        <option value="site_name" <?php echo $sort_by == 'site_name' ? 'selected' : ''; ?>>Site Name</option>
                                        <option value="site_manager" <?php echo $sort_by == 'site_manager' ? 'selected' : ''; ?>>Manager</option>
                                        <option value="site_address" <?php echo $sort_by == 'site_address' ? 'selected' : ''; ?>>Address</option>
                                        <option value="total_employees" <?php echo $sort_by == 'total_employees' ? 'selected' : ''; ?>>Total Employees</option>
                                        <option value="present_count" <?php echo $sort_by == 'present_count' ? 'selected' : ''; ?>>Present</option>
                                        <option value="absent_count" <?php echo $sort_by == 'absent_count' ? 'selected' : ''; ?>>Absent</option>
                                        <option value="leave_count" <?php echo $sort_by == 'leave_count' ? 'selected' : ''; ?>>On Leave</option>
                                        <option value="attendance_rate" <?php echo $sort_by == 'attendance_rate' ? 'selected' : ''; ?>>Attendance Rate</option>
                                    </select>
                                    <button type="submit" name="sort_order" value="<?php echo $sort_order == 'ASC' ? 'DESC' : 'ASC'; ?>" class="site-sort-btn">
                                        <i class="fas fa-sort-amount-<?php echo $sort_order == 'ASC' ? 'down' : 'up'; ?>"></i>
                                        <?php echo $sort_order == 'ASC' ? 'Asc' : 'Desc'; ?>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <?php if (empty($sites)): ?>
                        <div class="no-data">
                            <i class="fas fa-map-marked-alt"></i>
                            <p>No sites found</p>
                            <div class="sub-text">
                                <?php if (!empty($search_query)): ?>
                                    No sites match your search criteria.
                                <?php elseif (empty($total_stats['total_sites'])): ?>
                                    Please add sites in the Site Monitoring page.
                                <?php else: ?>
                                    No employees assigned to any site yet.
                                <?php endif; ?>
                            </div>
                            <?php if (!empty($search_query)): ?>
                            <a href="home.php?date=<?php echo urlencode($filter_date); ?>" class="clear-search-btn">
                                <i class="fas fa-times"></i> Clear Search
                            </a>
                            <?php else: ?>
                            <a href="site_monitoring.php" style="display: inline-block; margin-top: 20px; padding: 10px 24px; background: #2E7D32; color: white; text-decoration: none; border-radius: 30px; font-weight: 600;">
                                <i class="fas fa-plus-circle"></i> Manage Sites
                            </a>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="sites-grid">
                            <?php foreach ($sites as $site): ?>
                                <?php 
                                $total_employees = intval($site['total_employees'] ?? 0);
                                $present_count = intval($site['present_count'] ?? 0);
                                $leave_count = intval($site['leave_count'] ?? 0);
                                $absent_count = intval($site['absent_count'] ?? 0);
                                $attendance_rate = intval($site['attendance_rate'] ?? 0);
                                $display_name = isset($site['is_others']) && $site['is_others'] == 1 && !empty($site['assignment_type']) 
                                    ? $site['assignment_type'] 
                                    : $site['site_name'];
                                ?>
                                <div class="site-card">
                                    <div class="site-header">
                                        <h3>
                                            <?php if (isset($site['is_others']) && $site['is_others'] == 1): ?>
                                                <i class="fas fa-tasks"></i>
                                            <?php else: ?>
                                                <i class="fas fa-building"></i>
                                            <?php endif; ?>
                                            <?php echo htmlspecialchars($display_name); ?>
                                            <?php if (isset($site['is_others']) && $site['is_others'] == 1): ?>
                                                <span style="font-size: 11px; background: #e8f5e9; color: #2E7D32; padding: 3px 8px; border-radius: 12px; margin-left: 8px;">
                                                    Others
                                                </span>
                                            <?php endif; ?>
                                        </h3>
                                        <p>
                                            <i class="fas fa-user-tie"></i>
                                            <?php echo htmlspecialchars($site['site_manager'] ?? 'No manager'); ?>
                                        </p>
                                        <p>
                                            <i class="fas fa-map-marker-alt"></i>
                                            <?php echo htmlspecialchars($site['site_address'] ?? 'No address'); ?>
                                        </p>
                                        <?php if (isset($site['is_others']) && $site['is_others'] == 1 && !empty($site['person_group'])): ?>
                                        <p style="color: #2E7D32;">
                                            <i class="fas fa-users"></i>
                                            Group: <?php echo htmlspecialchars($site['person_group']); ?>
                                        </p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="site-content">
                                        <!-- MODIFIED: Employee stats with 4 items -->
                                        <div class="employee-stats">
                                            <div class="stat-item">
                                                <div class="stat-label">Total</div>
                                                <div class="stat-value"><?php echo $total_employees; ?></div>
                                            </div>
                                            <div class="stat-item">
                                                <div class="stat-label">Present</div>
                                                <div class="stat-value present"><?php echo $present_count; ?></div>
                                            </div>
                                            <div class="stat-item">
                                                <div class="stat-label">Absent</div>
                                                <div class="stat-value absent"><?php echo $absent_count; ?></div>
                                            </div>
                                            <div class="stat-item">
                                                <div class="stat-label">On Leave</div>
                                                <div class="stat-value leave"><?php echo $leave_count; ?></div>
                                            </div>
                                        </div>
                                        
                                        <div class="progress-section">
                                            <div class="progress-header">
                                                <span class="progress-label">Attendance Rate</span>
                                                <span class="progress-percent"><?php echo $attendance_rate; ?>%</span>
                                            </div>
                                            <div class="progress-bar">
                                                <div class="progress-fill" style="width: <?php echo $attendance_rate; ?>%;"></div>
                                            </div>
                                        </div>
                                        
                                        <div class="site-footer">
                                            <span style="color: #64748b; font-size: 12px;">
                                                <i class="fas fa-users"></i>
                                                <?php echo $total_employees; ?> assigned
                                            </span>
                                            <button onclick="viewSiteEmployees(<?php echo $site['id']; ?>)" class="view-details-btn">
                                                <i class="fas fa-eye"></i>
                                                More Details
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Date Information Footer -->
                <div class="date-info">
                    <span>
                        <i class="fas fa-info-circle"></i>
                        Showing data for: <strong><?php echo date('F d, Y', strtotime($filter_date)); ?></strong>
                    </span>
                    <?php if ($filter_date != date('Y-m-d')): ?>
                    <a href="home.php" class="today-link">
                        <i class="fas fa-calendar-day"></i>
                        View Today
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <!-- Site Employees Modal -->
    <div id="siteEmployeesModal" class="modal">
        <div class="modal-content" style="max-width: 1300px;">
            <div class="modal-header">
                <h3>
                    <i class="fas fa-users"></i>
                    Site Employees
                </h3>
                <button class="modal-close" onclick="closeEmployeesModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div id="siteInfoContainer" class="site-info-modal">
                    <!-- Site info will be loaded here -->
                </div>
                <div id="employeesListModalContainer">
                    <div class="loading">
                        <i class="fas fa-spinner fa-spin"></i>
                        <p>Loading employees...</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeEmployeesModal()">
                    <i class="fas fa-times"></i>
                    Close
                </button>
                <a href="site_monitoring.php" class="btn btn-primary">
                    <i class="fas fa-cog"></i>
                    Manage Sites
                </a>
            </div>
        </div>
    </div>

    <!-- footer -->
    <?php include_once("./includes/footer.php"); ?>
    
    <!-- modal -->
    <?php include_once("./modal/logout-modal.php"); ?>

    <script>
        // ============================================
        // DATE FILTER CALENDAR FUNCTIONS
        // ============================================
        let mainCurrentDate = new Date('<?= $filter_date ?>');
        let mainSelectedDate = '<?= $filter_date ?>';

        function toggleMainCalendar() {
            const calendar = document.getElementById('mainCalendarWrapper');
            if (calendar) {
                if (calendar.style.display === 'block') {
                    calendar.style.display = 'none';
                } else {
                    updateMainCalendarSelectors();
                    generateMainCalendarDays();
                    calendar.style.display = 'block';
                }
            }
        }

        function updateMainCalendarSelectors() {
            const monthSelect = document.getElementById('mainMonthSelect');
            const yearSelect = document.getElementById('mainYearSelect');
            
            if (monthSelect) {
                monthSelect.value = mainCurrentDate.getMonth();
            }
            if (yearSelect) {
                yearSelect.value = mainCurrentDate.getFullYear();
            }
        }

        function changeMainMonthYear() {
            const monthSelect = document.getElementById('mainMonthSelect');
            const yearSelect = document.getElementById('mainYearSelect');
            
            if (monthSelect && yearSelect) {
                const newMonth = parseInt(monthSelect.value);
                const newYear = parseInt(yearSelect.value);
                
                mainCurrentDate = new Date(newYear, newMonth, 1);
                generateMainCalendarDays();
            }
        }

        function generateMainCalendarDays() {
            const year = mainCurrentDate.getFullYear();
            const month = mainCurrentDate.getMonth();
            const daysGrid = document.getElementById('mainCalendarDaysGrid');
            const monthYearDisplay = document.getElementById('mainCalendarMonthYear');
            
            if (!daysGrid || !monthYearDisplay) return;
            
            monthYearDisplay.textContent = mainCurrentDate.toLocaleDateString('en-US', { 
                month: 'long', 
                year: 'numeric' 
            });
            
            updateMainCalendarSelectors();
            
            const firstDay = new Date(year, month, 1).getDay();
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            const today = new Date();
            
            let html = '';
            
            const prevMonthDays = new Date(year, month, 0).getDate();
            for (let i = firstDay - 1; i >= 0; i--) {
                const day = prevMonthDays - i;
                const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                html += `<div class="main-calendar-day other-month" onclick="selectMainDate('${dateStr}')">${day}</div>`;
            }
            
            for (let day = 1; day <= daysInMonth; day++) {
                const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                const isToday = today.getFullYear() === year && today.getMonth() === month && today.getDate() === day;
                const isSelected = dateStr === mainSelectedDate;
                const isWeekend = new Date(year, month, day).getDay() === 0 || new Date(year, month, day).getDay() === 6;
                
                let classes = 'main-calendar-day';
                if (isToday) classes += ' today';
                if (isSelected) classes += ' selected';
                if (isWeekend) classes += ' weekend';
                
                html += `<div class="${classes}" onclick="selectMainDate('${dateStr}')">${day}</div>`;
            }
            
            const totalCells = 42;
            const cellsUsed = firstDay + daysInMonth;
            const nextMonthDays = totalCells - cellsUsed;
            for (let day = 1; day <= nextMonthDays; day++) {
                const dateStr = `${year}-${String(month + 2).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                html += `<div class="main-calendar-day other-month" onclick="selectMainDate('${dateStr}')">${day}</div>`;
            }
            
            daysGrid.innerHTML = html;
        }

        function navigateMainMonth(direction) {
            mainCurrentDate.setMonth(mainCurrentDate.getMonth() + direction);
            generateMainCalendarDays();
        }

        function selectMainDate(dateStr) {
            const date = new Date(dateStr);
            const formattedDisplay = date.toLocaleDateString('en-US', {
                month: '2-digit',
                day: '2-digit',
                year: 'numeric'
            });
            
            const dateDisplay = document.getElementById('mainDateDisplay');
            const dateHidden = document.getElementById('selectedDate');
            
            if (dateDisplay) dateDisplay.textContent = formattedDisplay;
            if (dateHidden) dateHidden.value = dateStr;
            
            mainSelectedDate = dateStr;
            mainCurrentDate = new Date(dateStr);
            
            generateMainCalendarDays();
            
            const calendar = document.getElementById('mainCalendarWrapper');
            if (calendar) calendar.style.display = 'none';
            
            const currentUrl = new URL(window.location.href);
            currentUrl.searchParams.set('date', dateStr);
            currentUrl.searchParams.set('search', '<?= $search_query ?>');
            currentUrl.searchParams.set('sort_by', '<?= $sort_by ?>');
            currentUrl.searchParams.set('sort_order', '<?= $sort_order ?>');
            window.location.href = currentUrl.toString();
        }

        function clearMainDate() {
            const dateDisplay = document.getElementById('mainDateDisplay');
            const dateHidden = document.getElementById('selectedDate');
            
            if (dateDisplay) dateDisplay.textContent = 'Select Date';
            if (dateHidden) dateHidden.value = '';
            
            mainSelectedDate = '';
            
            const calendar = document.getElementById('mainCalendarWrapper');
            if (calendar) calendar.style.display = 'none';
        }

        function setMainToday() {
            const today = new Date();
            const year = today.getFullYear();
            const month = String(today.getMonth() + 1).padStart(2, '0');
            const day = String(today.getDate()).padStart(2, '0');
            const dateStr = `${year}-${month}-${day}`;
            
            mainCurrentDate = new Date(dateStr);
            selectMainDate(dateStr);
        }

        function quickDateSelect(date) {
            if (date) {
                window.location.href = 'home.php?date=' + encodeURIComponent(date) +
                    '&search=<?php echo urlencode($search_query); ?>' +
                    '&sort_by=<?php echo urlencode($sort_by); ?>' +
                    '&sort_order=<?php echo urlencode($sort_order); ?>';
            }
        }
        
        // View site employees
        function viewSiteEmployees(siteId) {
            const modal = document.getElementById('siteEmployeesModal');
            modal.style.display = 'flex';
            document.body.classList.add('modal-open');
            
            loadSiteEmployees(siteId);
        }
        
        // Close employees modal
        function closeEmployeesModal() {
            const modal = document.getElementById('siteEmployeesModal');
            modal.style.display = 'none';
            document.body.classList.remove('modal-open');
            
            document.getElementById('siteInfoContainer').innerHTML = '';
            document.getElementById('employeesListModalContainer').innerHTML = `
                <div class="loading">
                    <i class="fas fa-spinner fa-spin"></i>
                    <p>Loading employees...</p>
                </div>
            `;
        }
        
        // Load site employees via AJAX - MODIFIED for multi-line time display
        async function loadSiteEmployees(siteId) {
            const date = '<?php echo $filter_date; ?>';
            
            try {
                const response = await fetch(`get_site_employees_attendance.php?site_id=${siteId}&date=${encodeURIComponent(date)}`);
                const data = await response.json();
                
                if (data.success) {
                    const siteInfoContainer = document.getElementById('siteInfoContainer');
                    siteInfoContainer.innerHTML = `
                        <p><i class="fas fa-building"></i> <strong>${data.site_name}</strong></p>
                        <p><i class="fas fa-user-tie"></i> Manager: ${data.site_manager || 'N/A'}</p>
                        <p><i class="fas fa-map-marker-alt"></i> Address: ${data.site_address || 'N/A'}</p>
                        <p><i class="fas fa-calendar-alt"></i> Date: ${new Date(data.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
                        <p><i class="fas fa-users"></i> Total Employees: ${data.employees.length}</p>
                    `;
                    
                    const container = document.getElementById('employeesListModalContainer');
                    
                    if (data.employees && data.employees.length > 0) {
                        let html = `
                            <div class="employees-table-container">
                                <table class="employees-table">
                                    <thead>
                                        <tr>
                                            <th><i class="fas fa-user"></i> Employee</th>
                                            <th><i class="fas fa-briefcase"></i> Position</th>
                                            <th><i class="fas fa-sun"></i> AM Status</th>
                                            <th><i class="fas fa-moon"></i> PM Status</th>
                                            <th><i class="fas fa-clock"></i> Time Details</th>
                                            <th><i class="fas fa-hourglass-half"></i> Total Hours</th>
                                            <th><i class="fas fa-comment"></i> Remarks</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                        `;
                        
                        data.employees.forEach(emp => {
                            // AM Status
                            const amStatus = emp.status_am || 'Absent';
                            const amStatusClass = amStatus === 'Present' ? 'status-present' : (amStatus === 'On Leave' ? 'status-leave' : 'status-absent');
                            
                            // PM Status
                            const pmStatus = emp.status_pm || 'Absent';
                            const pmStatusClass = pmStatus === 'Present' ? 'status-present' : (pmStatus === 'On Leave' ? 'status-leave' : 'status-absent');
                            
                            // Format time details
                            let amTimeIn = (emp.time_in_am && emp.time_in_am != '00:00:00') ? emp.time_in_am.substring(0,5) : '--:--';
                            let amTimeOut = (emp.time_out_am && emp.time_out_am != '00:00:00') ? emp.time_out_am.substring(0,5) : '--:--';
                            let pmTimeIn = (emp.time_in_pm && emp.time_in_pm != '00:00:00') ? emp.time_in_pm.substring(0,5) : '--:--';
                            let pmTimeOut = (emp.time_out_pm && emp.time_out_pm != '00:00:00') ? emp.time_out_pm.substring(0,5) : '--:--';
                            
                            // Total hours from database
                            let hoursDisplay = '—';
                            if (emp.total_hours && parseFloat(emp.total_hours) > 0) {
                                const hours = parseFloat(emp.total_hours).toFixed(2);
                                hoursDisplay = `${hours} hrs`;
                            } else if (amStatus === 'Present' || pmStatus === 'Present') {
                                hoursDisplay = '0.00 hrs';
                            }
                            
                            let remarksDisplay = emp.remarks ? emp.remarks : '—';
                            
                            html += `
                                <tr>
                                    <td>
                                        <span>${emp.first_name} ${emp.last_name}</span>
                                        <div style="font-size: 0.75rem; color: #64748b;">ID: ${emp.id}</div>
                                    </td>
                                    <td>${emp.position || '—'}</td>
                                    <td>
                                        <span class="status-badge ${amStatusClass}">
                                            <i class="fas ${amStatus === 'Present' ? 'fa-check-circle' : (amStatus === 'On Leave' ? 'fa-umbrella-beach' : 'fa-times-circle')}"></i>
                                            ${amStatus}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="status-badge ${pmStatusClass}">
                                            <i class="fas ${pmStatus === 'Present' ? 'fa-check-circle' : (pmStatus === 'On Leave' ? 'fa-umbrella-beach' : 'fa-times-circle')}"></i>
                                            ${pmStatus}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="time-badge">
                                            <div class="time-row">
                                                <span class="time-label"><i class="fas fa-sun"></i> AM:</span>
                                                <span class="time-value">${amTimeIn} - ${amTimeOut}</span>
                                            </div>
                                            <div class="time-row">
                                                <span class="time-label"><i class="fas fa-moon"></i> PM:</span>
                                                <span class="time-value">${pmTimeIn} - ${pmTimeOut}</span>
                                            </div>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="time-badge" style="font-weight: 600; color: #2E7D32;">
                                            ${hoursDisplay}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="time-badge" style="color: #64748b; max-width: 200px; white-space: normal; word-wrap: break-word;">
                                            ${remarksDisplay}
                                        </span>
                                    </td>
                                </tr>
                            `;
                        });
                        
                        html += `
                                    </tbody>
                                </table>
                            </div>
                        `;
                        
                        container.innerHTML = html;
                    } else {
                        container.innerHTML = `
                            <div class="no-employees">
                                <i class="fas fa-user-slash"></i>
                                <p>No employees assigned to this site</p>
                            </div>
                        `;
                    }
                } else {
                    throw new Error(data.message || 'Failed to load employees');
                }
            } catch (error) {
                console.error('Error loading site employees:', error);
                document.getElementById('employeesListModalContainer').innerHTML = `
                    <div class="no-employees">
                        <i class="fas fa-exclamation-triangle" style="color: #dc2626;"></i>
                        <p>Error loading employees</p>
                        <div class="sub-text">${error.message}</div>
                    </div>
                `;
            }
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('siteEmployeesModal');
            if (event.target === modal) {
                closeEmployeesModal();
            }
        }
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeEmployeesModal();
                
                const calendar = document.getElementById('mainCalendarWrapper');
                if (calendar && calendar.style.display === 'block') {
                    calendar.style.display = 'none';
                }
            }
        });

        // Close calendar when clicking outside
        document.addEventListener('click', function(e) {
            const mainDatePicker = document.querySelector('.main-date-picker-wrapper');
            const mainCalendar = document.getElementById('mainCalendarWrapper');
            
            if (mainDatePicker && mainCalendar && !mainDatePicker.contains(e.target)) {
                mainCalendar.style.display = 'none';
            }
        });
        
        // Initialize calendar on page load
        document.addEventListener('DOMContentLoaded', function() {
            generateMainCalendarDays();
            
            setTimeout(() => {
                document.querySelectorAll('.progress-fill').forEach(bar => {
                    const width = bar.style.width;
                    bar.style.width = '0%';
                    setTimeout(() => {
                        bar.style.width = width;
                    }, 100);
                });
            }, 200);
        });
    </script>

</body>
</html>
<?php $conn->close(); ?>